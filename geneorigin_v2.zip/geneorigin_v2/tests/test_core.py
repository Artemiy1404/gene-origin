"""Быстрые самопроверки (python tests/test_core.py). Не требуют BLAST."""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))

from coding_potential import score_pvalue                       # noqa: E402
from io_utils import parse_record_header, parse_loc             # noqa: E402
from regions import codon_walk, predicted_defects                # noqa: E402
from species import LINEAGE_INDEX                                # noqa: E402


def test_random_model():
    # CG43181 (128 аа): D. persimilis Genewise 11.2 -> не ген; D. willistoni Spaln 270 -> ген
    assert abs(score_pvalue(11.2, 128, "genewise")[2] - 0.030) < 0.001
    assert score_pvalue(270.0, 128, "spaln")[2] < 1e-6


def test_headers():
    r = parse_record_header("dper|NW_020825322.1-:709401:710983|score_87.0|shift_No|1")
    assert not r["annotated"] and r["score"] == 87.0 and r["strand"] == "-" and r["start"] == 709401
    assert parse_record_header("dsim|Dsimw501_GD28905|score_1E10|shift_No|1")["annotated"]
    assert parse_loc("X:complement(join(10..20,30..40))") == ("X", "-", [(10, 20), (30, 40)])


def test_defects():
    d = predicted_defects("ATAAAATAGCCC", False)          # нет ATG, стоп внутри
    assert not d["starts_with_ATG"] and d["internal_stops"] == 1
    hsp = {"qstart": 1, "qseq": "ATGAAATGA", "sseq": "ATAAAATAA", "evalue": 1e-5}
    w = codon_walk([hsp], 9)
    assert w["codon_at_ATG"] == "ATA" and w["codon_at_stop"] == "TAA"


def test_lineages():
    assert LINEAGE_INDEX["dfic"] == 2 and LINEAGE_INDEX["dwil"] == 7 and LINEAGE_INDEX["sleb"] == 8


def test_reconstruction_frameshift():
    # синтетика: участок вида = CDS без ATG и с делецией 1 н. на 20-м кодоне -> сдвиг рамки
    import random
    from reconstruction import compare
    rnd = random.Random(1)
    body = "".join(rnd.choice("ACGT") for _ in range(240)).replace("TAA", "TCA").replace("TAG", "TCG").replace("TGA", "TCA")
    cds = "ATG" + body + "TAA"
    flank = "".join(rnd.choice("ACGT") for _ in range(60))
    region = flank + "ATA" + body[:57] + body[58:] + "TAA" + flank
    r = compare(cds, region, n_null=2)
    assert r["homologous"] and r["start_triplet"] == "ATA"
    assert r["frameshifts"] and abs(r["frameshifts"][0]["codon"] - 20) <= 1


def test_read_input_dir():
    from io_utils import read_input_dir
    here = os.path.join(os.path.dirname(__file__), "..", "examples", "input_fasta")
    g = read_input_dir(here)
    assert "FBgn0262810" in g
    raw = g["FBgn0262810"]["raw"]
    assert raw[0]["species"] == "dmel" and raw[0]["annotated"]
    assert any(not r["annotated"] for r in raw)


def test_copy_mechanism_needs_evidence():
    from decision_tree import copy_mechanism
    # нет данных об ортологах и стыках -> не «ретрокопия», а «предполагаемая»
    d = {"intron_check": {"single_exon": "A", "multi_exon": "B", "status": "putative"}}
    assert copy_mechanism(d, "A")[0] == "putative_retrocopy"
    # копия похожа только на один экзон -> механизм не уточнён (раньше автоматически dna_duplication)
    d = {"intron_check": {"single_exon": "A", "multi_exon": "B", "status": "not_supported"}}
    assert copy_mechanism(d, "A")[0] == "mechanism_unresolved"
    d = {"intron_check": {"status": "same_structure"}}
    assert copy_mechanism(d, "A")[0] == "mechanism_unresolved"


def test_reconstruction_n_region():
    from reconstruction import compare
    r = compare("ATG" + "GCT" * 40 + "TAA", "N" * 90)
    assert not r["homologous"] and r.get("insufficient")


def test_distinct_triplets_not_merged_into_one_substitution():
    from reconstruction import polarize, describe
    base = {"homologous": True, "aligned_codons": list(range(1, 30))}
    per = {"dana": {**base, "events": [{"type": "start", "codon": 1, "species_triplet": "ATA", "gene_triplet": "ATG",
                                        "kind": "замена", "detail": "A→G в 3-й позиции"}]},
           "dpse": {**base, "events": [{"type": "start", "codon": 1, "species_triplet": "ATT", "gene_triplet": "ATG",
                                        "kind": "замена", "detail": "T→G в 3-й позиции"}]},
           "dkik": {**base, "events": []}}
    ev = polarize(per, 4, ["dkik"])
    st = [e for e in ev if e["type"] == "start"][0]
    assert st["detail"] is None and st["carrier_triplets"] == {"dana": "ATA", "dpse": "ATT"}
    assert "ATA" in describe(st) and "ATT" in describe(st)


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_"):
            fn()
            print("ok", name)
