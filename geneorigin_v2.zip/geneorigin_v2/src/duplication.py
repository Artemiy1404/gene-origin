"""duplication.py — ветка «найден паралог»: кто из двух копий родитель?

Признаки (все считаются из данных, ничего не вписывается руками):
  1. Распространение по видам: у каких видов есть ортолог каждой копии. Ортолог = взаимная лучшая
     находка (RBH) между белком dmel и протеомом вида. Родитель — та копия, что есть у более дальних видов.
  2. Синтения: у вида с одной копией смотрим соседей. Если рядом лежат ортологи соседей копии A
     (а не B), значит эта единственная копия стоит на «адресе» A -> A старше.
  3. Интроны: у одной копии 1 кодирующий экзон, у другой несколько. Ретрокопия ПОДТВЕРЖДЕНА, только если
     безынтронная копия выравнивается через стык соседних экзонов многоэкзонной без разрыва (несёт
     соединённые экзоны, как мРНК) и у ортологов многоэкзонной копии интроны тоже есть. Стык есть, а
     ортологи не проверены -> «предполагаемая ретрокопия». Копия похожа только на один экзон -> признак
     не работает (возможна дупликация фрагмента ДНК). Нет данных -> «не проверено», а не «за».
  4. Дерево генов (если есть IQ-TREE и выравниватель): копия вложена в группу ортологов родителя.
Направление считается установленным, если совпали >= min_signals признаков из 1–3 и ни один не спорит.
"""
VERSION = "2.2-introns-junctions"  # меняется при изменении логики -> кэш ветки дупликации пересчитывается

import collections
import glob
import os
import re
import subprocess
import tempfile

from species import LINEAGE_INDEX


# ---------- разметка NCBI ----------
class SpeciesAnnotation:
    def __init__(self, gff_path):
        self.prot_cds = collections.defaultdict(list)   # protein_id -> [(seqid, start, end, strand)]
        self.genes = []                                  # (seqid, start, end, gene_id)
        self.prot_gene = {}
        with open(gff_path) as f:
            for line in f:
                if line.startswith("#"):
                    if line.startswith("##FASTA"):
                        break
                    continue
                c = line.rstrip("\n").split("\t")
                if len(c) != 9:
                    continue
                if c[2] == "gene":
                    gid = re.search(r"ID=([^;]+)", c[8]).group(1)
                    self.genes.append((c[0], int(c[3]), int(c[4]), gid))
                elif c[2] == "CDS":
                    m = re.search(r"protein_id=([^;]+)", c[8])
                    if m:
                        self.prot_cds[m.group(1)].append((c[0], int(c[3]), int(c[4]), c[6]))
        self.genes.sort()

    def locus(self, protein_id):
        segs = self.prot_cds.get(protein_id)
        if not segs:
            return None
        return {"seqid": segs[0][0], "start": min(s[1] for s in segs), "end": max(s[2] for s in segs),
                "strand": segs[0][3], "exons": len(segs)}


_ANN = {}


def load_annotation(gff_path):
    """Разбор GFF долгий, поэтому кэшируем в памяти и рядом с файлом."""
    import pickle
    if gff_path in _ANN:
        return _ANN[gff_path]
    cache = gff_path + ".geneorigin.pkl"
    if os.path.exists(cache):
        with open(cache, "rb") as f:
            _ANN[gff_path] = pickle.load(f)
        return _ANN[gff_path]
    ann = SpeciesAnnotation(gff_path)
    with open(cache, "wb") as f:
        pickle.dump(ann, f)
    _ANN[gff_path] = ann
    return ann


# ---------- blastp помощники ----------
def _clean_id(s):
    """'ref|XP_016025387.1|' -> 'XP_016025387.1'; 'lcl|dmel|FBpp..|FBgn..' -> 'dmel|FBpp..|FBgn..'."""
    if s.startswith("ref|") or s.startswith("gb|"):
        return s.split("|")[1]
    if s.startswith("lcl|"):
        return s[4:]
    return s


def _blast(query_seqs, db, blast_bin, evalue, max_targets=5):
    with tempfile.TemporaryDirectory() as tmp:
        q = os.path.join(tmp, "q.fa")
        with open(q, "w") as f:
            for k, v in query_seqs.items():
                f.write(f">{k}\n{v}\n")
        out = subprocess.run([os.path.join(blast_bin, "blastp"), "-query", q, "-db", db,
                              "-task", "blastp-fast", "-num_threads", "2",
                              "-evalue", str(evalue), "-max_target_seqs", str(max_targets),
                              "-outfmt", "6 qseqid sseqid evalue bitscore qcovs"],
                             capture_output=True, text=True, check=True).stdout
    best = {}
    for line in out.splitlines():
        q, s, e, b, cov = line.split("\t")
        s = _clean_id(s)
        if q not in best or float(b) > best[q][2]:
            best[q] = (s, float(e), float(b), float(cov))
    return best


def _fetch(db, ids, blast_bin):
    out = subprocess.run([os.path.join(blast_bin, "blastdbcmd"), "-db", db, "-entry", ",".join(ids)],
                         capture_output=True, text=True).stdout
    seqs, cur = {}, None
    for line in out.splitlines():
        if line.startswith(">"):
            cur = _clean_id(line[1:].split()[0])
            seqs[cur] = ""
        elif cur:
            seqs[cur] += line.strip()
    return seqs


def resolve_parent(gene_a, gene_b, fb, dmel_db, species_dirs, cfg, blast_bin="", tree_tools=None, workdir=None):
    """gene_a — исследуемый ген, gene_b — найденный паралог. species_dirs: {вид: папка NCBI}.
    dmel_db — BLAST-база только из белков dmel (id = dmel|FBpp|FBgn) для обратного поиска."""
    d = cfg["duplication"]
    pa, pb = fb.longest_protein(gene_a), fb.longest_protein(gene_b)
    seq = {gene_a: pa["seq"].rstrip("*"), gene_b: pb["seq"].rstrip("*")}
    ex = {gene_a: fb.max_exon_count(gene_a), gene_b: fb.max_exon_count(gene_b)}
    loc = {gene_a: fb.location(gene_a), gene_b: fb.location(gene_b)}
    nb = {g: fb.neighbors(g, d["neighbors_k"]) for g in (gene_a, gene_b)}
    nb_seq = {}
    for g in (gene_a, gene_b):
        for n in nb[g]:
            p = fb.longest_protein(n)
            if p:
                nb_seq[n] = p["seq"].rstrip("*")

    per_species = {}
    tree_seqs = {f"dmel_{loc[gene_a]['name']}": seq[gene_a], f"dmel_{loc[gene_b]['name']}": seq[gene_b]}
    for sp, sp_dir in species_dirs.items():
        faa = glob.glob(os.path.join(sp_dir, "ncbi_dataset/data/*/protein.faa"))
        gff = glob.glob(os.path.join(sp_dir, "ncbi_dataset/data/*/genomic.gff"))
        if not faa or not gff:
            continue
        sp_db = os.path.join(sp_dir, "blast_protein_db")
        if not os.path.exists(sp_db + ".pin") and not os.path.exists(sp_db + ".pdb"):
            subprocess.run([os.path.join(blast_bin, "makeblastdb"), "-in", faa[0], "-dbtype", "prot",
                            "-parse_seqids", "-out", sp_db], check=True, capture_output=True)
        ann = load_annotation(gff[0])
        fwd = _blast({**seq, **nb_seq}, sp_db, blast_bin, d["rbh_evalue"])
        # обратный поиск лучших находок против протеома dmel -> какой ген dmel им «родной»
        cand = {fwd[g][0] for g in (gene_a, gene_b) if g in fwd}
        cand_seq = _fetch(sp_db, sorted(cand), blast_bin)
        rev = _blast(cand_seq, dmel_db, blast_bin, d["rbh_evalue"], max_targets=20)
        rev_gene = {k: v[0].split("|")[2] for k, v in rev.items() if v[0].startswith("dmel|")}
        copies = {}
        for g in (gene_a, gene_b):
            if g in fwd:
                prot = fwd[g][0]
                prot_key = prot
                copies[g] = {"protein": prot_key, "evalue": fwd[g][1], "rbh": rev_gene.get(prot) == g,
                             "reverse_best": rev_gene.get(prot), "locus": ann.locus(prot_key)}

        # синтения: для каждой найденной копии считаем, чьи соседи лежат рядом
        synt = {}
        for g, c in copies.items():
            if not c["locus"]:
                continue
            near = {gene_a: 0, gene_b: 0}
            for owner in (gene_a, gene_b):
                for n in nb[owner]:
                    if n not in fwd:
                        continue
                    nl = ann.locus(fwd[n][0])
                    if nl and nl["seqid"] == c["locus"]["seqid"] and \
                            abs(nl["start"] - c["locus"]["start"]) <= d["synteny_window_bp"]:
                        near[owner] += 1
            synt[c["protein"]] = near
        # копия g есть у вида, если её лучшая находка — взаимно лучшая (RBH) ИЛИ лежит среди
        # соседей именно g (синтения сильнее BLAST для почти одинаковых копий, как Ntf-2/Ntf-2r)
        present = {}
        for g in (gene_a, gene_b):
            c = copies.get(g)
            other = gene_b if g == gene_a else gene_a
            near = synt.get(c["protein"], {}) if c else {}
            by_synteny = bool(near) and near.get(g, 0) > near.get(other, 0)
            present[g] = bool(c) and (c["rbh"] or by_synteny)
            if c:
                c["present_by"] = "rbh" if c["rbh"] else ("synteny" if by_synteny else None)
        per_species[sp] = {"lineage": LINEAGE_INDEX.get(sp), "present": present, "copies": copies,
                           "synteny_neighbors": synt}
        for g, c in copies.items():
            if present[g]:
                s = _fetch(sp_db, [fwd[g][0]], blast_bin)
                if s:
                    tree_seqs[f"{sp}_{loc[g]['name']}"] = next(iter(s.values()))

    # ---- признак 1: распространение ----
    far = {g: max([v["lineage"] for v in per_species.values() if v["present"][g]] + [-1])
           for g in (gene_a, gene_b)}
    if far[gene_a] == far[gene_b]:
        s1 = None
    else:
        s1 = gene_a if far[gene_a] > far[gene_b] else gene_b
    # ---- признак 2: синтения у видов с одной копией ----
    votes = collections.Counter()
    single_copy_species = []
    for sp, v in per_species.items():
        found = [c for c in v["copies"].values() if c["locus"]]
        prots = {c["protein"] for c in found}
        if len(prots) == 1:
            single_copy_species.append(sp)
            near = v["synteny_neighbors"].get(next(iter(prots)), {})
            if near.get(gene_a, 0) > near.get(gene_b, 0):
                votes[gene_a] += 1
            elif near.get(gene_b, 0) > near.get(gene_a, 0):
                votes[gene_b] += 1
    s2 = None
    if votes:
        top = votes.most_common()
        if len(top) == 1 or top[0][1] > top[1][1]:
            s2 = top[0][0]
    # ---- признак 3: интроны ----
    # Разное число экзонов само по себе ничего не доказывает. Ретрокопия подтверждается, только если
    # безынтронная копия несёт СОЕДИНЁННЫЕ последовательности соседних экзонов многоэкзонной копии
    # (выравнивание без разрыва проходит через стык экзонов) и у ортологов многоэкзонной копии интроны тоже есть.
    s3 = None
    intron_check = {"status": "same_structure", "ortholog_introns": None, "junctions": None}
    if ex[gene_a] and ex[gene_b] and (ex[gene_a] == 1) != (ex[gene_b] == 1):
        multi = gene_a if ex[gene_a] > 1 else gene_b
        single = gene_b if multi == gene_a else gene_a
        ortho_exons = [c["locus"]["exons"] for v in per_species.values()
                       for g, c in v["copies"].items() if g == multi and c["rbh"] and c["locus"]]
        ortho_ok = None if not ortho_exons else all(e > 1 for e in ortho_exons)
        jx = exon_junctions_spanned(fb, single, multi)
        intron_check = {"multi_exon": multi, "single_exon": single, "ortholog_introns": ortho_ok,
                        "ortholog_exon_counts": ortho_exons, "junctions": jx}
        if jx is None:
            intron_check["status"] = "putative" if ortho_ok is not False else "not_supported"
        elif jx["spanned"] >= 1 and ortho_ok:
            intron_check["status"] = "confirmed"
            s3 = multi
        elif jx["spanned"] >= 1:
            intron_check["status"] = "putative"         # стык есть, но интроны у ортологов не проверены/спорят
        else:
            intron_check["status"] = "not_supported"    # копия похожа только на один экзон
    elif ex[gene_a] and ex[gene_b] and ex[gene_a] > 1 and ex[gene_b] > 1:
        jx = shared_intron_positions(fb, gene_a, gene_b)
        intron_check = {"status": "introns_shared" if jx and jx["shared"] else "same_structure", "junctions": jx}
    retro = intron_check["status"] == "confirmed"
    signals = {"distribution": s1, "synteny": s2, "introns": s3}
    # ---- признак 4: дерево ----
    tree = None
    if tree_tools and len(tree_seqs) >= 4:
        tree = build_tree(tree_seqs, tree_tools, workdir or tempfile.mkdtemp(), cfg)
    tsig = tree_signal(tree, loc, None, None, cfg)
    vals = [v for v in signals.values() if v]
    parent = None
    if vals and len(set(vals)) == 1 and len(vals) >= d["min_signals"]:
        parent = vals[0]
    return {"gene": gene_a, "paralog": gene_b,
            "names": {g: loc[g]["name"] for g in loc}, "exons": ex, "locations": loc,
            "farthest_lineage": far, "single_copy_species": single_copy_species,
            "synteny_votes": dict(votes), "signals": signals, "retrocopy": retro,
            "intron_check": intron_check,
            "parent": parent, "copy": (gene_b if parent == gene_a else gene_a) if parent else None,
            "per_species": per_species, "tree": tree, "tree_signal": tsig}


# ---------- стыки экзонов ----------
def _cds_junctions_aa(fb, gene):
    """Позиции стыков экзонов в белке (аминокислоты от 0) для самой длинной CDS-изоформы."""
    cands = fb.cds_by_gene.get(gene, [])
    if not cands:
        return None, None
    # изоформа с наибольшим числом экзонов (при равенстве — самая длинная): интрон хотя бы в одной изоформе
    c = max(cands, key=lambda x: (len(x["segments"]), len(x["seq"])))
    if not c["segments"]:
        return None, None
    segs = list(c["segments"])
    if c["strand"] == "-":
        segs = segs[::-1]
    pos, out = 0, []
    for s, e in segs[:-1]:
        pos += e - s + 1
        out.append(pos // 3)
    return out, c


def _protein_alignment(a, b):
    from Bio import Align
    from Bio.Align import substitution_matrices
    al = Align.PairwiseAligner()
    al.mode = "local"
    al.substitution_matrix = substitution_matrices.load("BLOSUM62")
    al.open_gap_score, al.extend_gap_score = -11, -1
    return al.align(a, b)[0]


def exon_junctions_spanned(fb, single, multi, flank=10, slack=3):
    """Проходит ли выравнивание безынтронной копии через стыки экзонов многоэкзонной без разрыва.
    -> {"junctions": n, "spanned": k, "covered_exons": m, "positions": [...]} или None (нет данных)."""
    junc, _ = _cds_junctions_aa(fb, multi)
    ps, pm = fb.longest_protein(single), fb.longest_protein(multi)
    if not junc or not ps or not pm:
        return None
    aln = _protein_alignment(ps["seq"].rstrip("*"), pm["seq"].rstrip("*"))
    blocks = [(int(b0), int(b1)) for b0, b1 in aln.aligned[1]]      # отрезки в белке многоэкзонной копии
    if not blocks:
        return {"junctions": len(junc), "spanned": 0, "covered_exons": 0, "positions": []}
    lo, hi = blocks[0][0], blocks[-1][1]
    spanned = []
    for j in junc:
        if j - flank < lo or j + flank > hi:
            continue
        # стык внутри одного непрерывного блока (± slack) = в копии нет вставки на месте интрона
        if any(b0 <= j - slack and j + slack <= b1 for b0, b1 in blocks):
            spanned.append(j)
    edges = [0] + junc + [len(pm["seq"])]
    covered = sum(1 for s, e in zip(edges, edges[1:]) if min(e, hi) - max(s, lo) >= flank)
    return {"junctions": len(junc), "spanned": len(spanned), "covered_exons": covered,
            "positions": spanned, "aligned_aa": [lo, hi]}


def shared_intron_positions(fb, a, b, slack=3):
    """Обе копии многоэкзонные: совпадают ли места интронов (по выравниванию белков)."""
    ja, _ = _cds_junctions_aa(fb, a)
    jb, _ = _cds_junctions_aa(fb, b)
    pa, pb = fb.longest_protein(a), fb.longest_protein(b)
    if not ja or not jb or not pa or not pb:
        return None
    aln = _protein_alignment(pa["seq"].rstrip("*"), pb["seq"].rstrip("*"))
    amap = {}
    for (a0, a1), (b0, b1) in zip(aln.aligned[0], aln.aligned[1]):
        for k in range(int(a1) - int(a0)):
            amap[int(a0) + k] = int(b0) + k
    shared = [j for j in ja if j in amap and any(abs(amap[j] - x) <= slack for x in jb)]
    return {"shared": len(shared), "introns_a": len(ja), "introns_b": len(jb)}


def build_tree(seqs, tools, workdir, cfg):
    os.makedirs(workdir, exist_ok=True)
    fa = os.path.join(workdir, "family.faa")
    with open(fa, "w") as f:
        for k, v in seqs.items():
            f.write(f">{k}\n{v.rstrip('*')}\n")
    aln = os.path.join(workdir, "family.aln.faa")
    if os.path.basename(tools["aligner"]).startswith("muscle"):
        subprocess.run([tools["aligner"], "-align", fa, "-output", aln], check=True, capture_output=True)
    else:
        with open(aln, "w") as out:
            subprocess.run([tools["aligner"], "--auto", "--quiet", fa], check=True, stdout=out)
    prefix = os.path.join(workdir, "tree")
    subprocess.run([tools["iqtree"], "-s", aln, "-m", "MFP", "-B", "1000", "-alrt", "1000",
                    "--seed", str(cfg["seed"]), "-T", "1", "--prefix", prefix, "-redo", "--quiet"],
                   check=True, capture_output=True)
    newick = open(prefix + ".treefile").read().strip()
    model = ""
    for line in open(prefix + ".iqtree"):
        if line.startswith("Best-fit model"):
            model = line.split(":")[1].strip()
    return {"newick": newick, "model": model, "alignment": aln, "n_seqs": len(seqs),
            "supports": _supports(newick)}


def _supports(newick):
    """Все значения поддержки SH-aLRT/UFBoot во внутренних узлах."""
    vals = []
    for m in re.finditer(r"\)([0-9.]+)/([0-9.]+):", newick):
        vals.append((float(m.group(1)), float(m.group(2))))
    return vals


def tree_signal(tree, names, parent_name, copy_name, cfg):
    """Разрешено ли дерево: есть ли узлы с поддержкой SH-aLRT >= 80 и UFBoot >= 95."""
    if not tree:
        return {"resolved": None, "note": "дерево не строилось"}
    ph = cfg.get("phylo", {})
    good = [s for s in tree["supports"] if s[0] >= ph.get("support_alrt", 80) and s[1] >= ph.get("support_ufboot", 95)]
    return {"resolved": bool(good), "n_supported_nodes": len(good), "n_nodes": len(tree["supports"]),
            "note": "есть надёжные узлы" if good else "белковое дерево не разрешено: решают признаки 1-3"}
