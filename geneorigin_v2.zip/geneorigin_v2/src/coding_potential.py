"""coding_potential.py — можно ли считать неразмеченный участок геном (ортологом)?

Модель случайных симуляций из Peng & Zhao 2024 (Methods, «Random simulations of Genewise/Spaln»):
для случайного белка длины N и случайной ДНК авторы получили среднее и SD нормированного
счёта сплайсированного выравнивания (score / N) и аппроксимировали их двухфазным спадом.
Параметры скопированы из extract_alnscore_genewise.py (репозиторий LiZhaoLab/DrosophilaDenovoGene).

P = 1 - Phi((score/N - mean(N)) / sd(N)) — вероятность получить такой счёт на НЕродственной ДНК.
Маленькое P -> участок похож на ген больше, чем случайный -> «неразмеченный ортолог».
Порог авторов P < 1e-6 (mean + 4.75 SD).
"""
import math

PARAMS = {
    ("genewise", "mean"): (0.010964339, 0.015192716, 0.322977380, 0.148062602, 10.840972709),
    ("genewise", "sd"):   (0.000000102, 0.020887105, 0.001636796, 0.190068618, 0.020123856),
    ("spaln", "mean"):    (-0.039279974, 0.015644801, 0.088245361, 2.736299221, 15.302980734),
    ("spaln", "sd"):      (0.000000000, 0.001565254, 0.036506722, 0.128773380, 1.049427652),
}


def _two_phase(n, plateau, kfast, kslow, spanfast, spanslow):
    return plateau + spanfast * math.exp(-kfast * n) + spanslow * math.exp(-kslow * n)


def random_expectation(n_aa, method):
    """mean и SD нормированного счёта для случайной пары белок/ДНК длины n_aa."""
    return (_two_phase(n_aa, *PARAMS[(method, "mean")]),
            _two_phase(n_aa, *PARAMS[(method, "sd")]))


def norm_sf(z):
    return 0.5 * math.erfc(z / math.sqrt(2))


def score_pvalue(raw_score, n_aa, method):
    """-> (normalized_score, z, p). raw_score — из заголовка секции II/III (score_...)."""
    mean, sd = random_expectation(n_aa, method)
    s = raw_score / n_aa
    z = (s - mean) / sd
    return s, z, norm_sf(z)


def loglik_ratio_coding(raw_score, n_aa, method, coding_mean=None, coding_sd=None):
    """log10 отношения правдоподобия «ортолог» / «случайная ДНК» для одного участка.
    Если параметры распределения настоящих ортологов не заданы — None."""
    if coding_mean is None:
        return None
    mean, sd = random_expectation(n_aa, method)
    s = raw_score / n_aa
    def logpdf(x, m, v):
        return -0.5 * ((x - m) / v) ** 2 - math.log(v)
    return (logpdf(s, coding_mean, coding_sd) - logpdf(s, mean, sd)) / math.log(10)
