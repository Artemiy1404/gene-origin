"""homology.py — паралоги в геноме dmel и гомологи вне синтенного места (blastp).

Одна база all28: протеом dmel r6.36 (id = dmel|FBpp|FBgn) + протеомы 27 видов NCBI (id = вид|белок).
Запрос — самая длинная изоформа гена.
"""
import collections
import os
import subprocess

from species import LINEAGE_INDEX

FIELDS = "qseqid sseqid pident length qstart qend sstart send evalue bitscore qcovs qlen slen".split()


def build_db(proteomes, dmel_translation_records, out_prefix, blast_bin=""):
    """proteomes: {код_вида: путь к .faa}; dmel_translation_records — из io_utils.read_flybase_fasta."""
    fasta = out_prefix + ".faa"
    with open(fasta, "w") as out:
        for p in dmel_translation_records:
            par = next(iter(p["parent"]))
            out.write(f">dmel|{p['id']}|{par}\n{p['seq']}\n")
        for sp, path in sorted(proteomes.items()):
            with open(path) as f:
                for line in f:
                    out.write(f">{sp}|{line[1:].split()[0]}\n" if line.startswith(">") else line)
    subprocess.run([os.path.join(blast_bin, "makeblastdb"), "-in", fasta, "-dbtype", "prot",
                    "-out", out_prefix, "-parse_seqids"], check=True, capture_output=True)
    return out_prefix


def run_blastp(query_fa, db, out_tsv, evalue=1e-3, threads=2, blast_bin=""):
    subprocess.run([os.path.join(blast_bin, "blastp"), "-query", query_fa, "-db", db,
                    "-evalue", str(evalue), "-max_target_seqs", "1000", "-seg", "yes",
                    "-num_threads", str(threads), "-outfmt", "6 " + " ".join(FIELDS),
                    "-out", out_tsv], check=True)
    return out_tsv


def read_hits(tsv):
    hits = collections.defaultdict(list)
    with open(tsv) as f:
        for line in f:
            v = dict(zip(FIELDS, line.rstrip("\n").split("\t")))
            for k in ("pident", "evalue", "bitscore", "qcovs"):
                v[k] = float(v[k])
            for k in ("length", "qstart", "qend", "sstart", "send", "qlen", "slen"):
                v[k] = int(v[k])
            parts = v["sseqid"].split("|")
            v["species"] = parts[0]
            v["subject_gene"] = parts[2] if parts[0] == "dmel" and len(parts) > 2 else None
            hits[v["qseqid"]].append(v)
    return hits


def paralogs(gene_hits, gene_id, cfg):
    """Похожие белки dmel из ДРУГИХ генов (изоформы своего гена исключены по parent=)."""
    h = cfg["homology"]
    best = {}
    for x in gene_hits:
        if x["species"] != "dmel" or x["subject_gene"] == gene_id:
            continue
        if x["evalue"] < h["paralog_evalue"] and x["qcovs"] >= h["paralog_min_qcov"]:
            g = x["subject_gene"]
            if g not in best or x["bitscore"] > best[g]["bitscore"]:
                best[g] = x
    return sorted(best.values(), key=lambda x: x["evalue"])


def outside_homologs(gene_hits, beyond_lineage, cfg):
    """Гомологи у видов дальше линии beyond_lineage (т.е. во внешних группах и у далёких
    членистоногих). Синтенный участок там не ген, значит находка лежит в ДРУГОМ месте генома."""
    h = cfg["homology"]
    per_species = {}
    for x in gene_hits:
        sp = x["species"]
        li = LINEAGE_INDEX.get(sp)
        if sp == "dmel" or li is None or li <= beyond_lineage:
            continue
        if x["evalue"] < h["outside_evalue"] and x["qcovs"] >= h["outside_min_qcov"]:
            if sp not in per_species or x["evalue"] < per_species[sp]["evalue"]:
                per_species[sp] = x
    return sorted(per_species.values(), key=lambda x: x["evalue"])


def species_presence(gene_hits, cfg):
    """Лучшая находка в каждом виде (для отчёта)."""
    out = {}
    for x in gene_hits:
        sp = x["species"]
        if sp == "dmel":
            continue
        if sp not in out or x["evalue"] < out[sp]["evalue"]:
            out[sp] = x
    return out
