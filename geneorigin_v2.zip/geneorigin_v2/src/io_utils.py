"""io_utils.py — чтение входных данных GeneOrigin v2.

1) supplementary_file_unannotated_alignments.txt (figshare 19989395):
   Section I   — сырые участки из Cactus (CDS ортологов + куски ДНК с того же места);
   Section II  — те же участки после сплайсированного выравнивания Spaln;
   Section III — то же после Genewise.
   Заголовок размеченного ортолога:  >dsim|Dsimw501_GD28905|score_1E10|shift_No|1
   Заголовок неразмеченного участка: >dper|NW_020825322.1-:709401:710983   (секция I)
                                      >dper|NW_020825322.1-:709401:710983|score_87.0|shift_No|1  (секции II/III)
2) FASTA FlyBase r6.36 (translation / CDS / transcript / gene): поля loc=, parent=, name=.
"""
import re
import gzip
import collections

SECTION_TAGS = {"raw sequence": "raw", "spaln": "spaln", "genewise": "genewise"}


def _open(path):
    return gzip.open(path, "rt") if str(path).endswith(".gz") else open(path)


def parse_record_header(header):
    """'dper|NW_020825322.1-:709401:710983|score_87.0|shift_No|1' -> dict."""
    parts = header.split("|")
    rec = {"header": header, "species": parts[0], "id": parts[1],
           "annotated": ":" not in parts[1], "score": None, "shift": None}
    for p in parts[2:]:
        if p.startswith("score_"):
            rec["score"] = float(p[6:])
        elif p.startswith("shift_"):
            rec["shift"] = p[6:] == "Yes"
    if not rec["annotated"]:
        m = re.match(r"(.+?)([+-]):(\d+):(\d+)$", parts[1])
        if m:
            rec.update(scaffold=m.group(1), strand=m.group(2),
                       start=int(m.group(3)), end=int(m.group(4)))
    return rec


def read_unannotated_alignments(path):
    """-> {gene_id: {"raw": [rec...], "spaln": [...], "genewise": [...]}}; rec содержит seq."""
    genes = collections.OrderedDict()
    tag = gene = None
    with _open(path) as handle:
        for line in handle:
            line = line.rstrip("\n")
            if not line.strip() or line.startswith("Section"):
                continue
            m = re.match(r"^(raw sequence|spaln|genewise) for dmel_(FBgn\d+)", line)
            if m:
                tag, gene = SECTION_TAGS[m.group(1)], m.group(2)
                genes.setdefault(gene, {"raw": [], "spaln": [], "genewise": []})
                continue
            if line.startswith(">"):
                rec = parse_record_header(line[1:])
                rec["seq"] = ""
                genes[gene][tag].append(rec)
            elif gene is not None:
                genes[gene][tag][-1]["seq"] += line.strip().upper()
    return genes


# ---------- FlyBase ----------
def _field(desc, name):
    m = re.search(rf"\b{name}=([^;]+);", desc + ";")
    return m.group(1).strip() if m else ""


def parse_loc(loc):
    """'2L:join(100..200,300..400)' / 'X:complement(join(...))' -> (chrom, strand, [(s,e),...])."""
    chrom, _, rest = loc.partition(":")
    strand = "-" if "complement" in rest else "+"
    segs = [(int(a), int(b)) for a, b in re.findall(r"(\d+)\.\.(\d+)", rest)]
    return chrom, strand, sorted(segs)


def read_flybase_fasta(path, keep_seq=True):
    """-> list of dict(id, name, parent(set FBgn), chrom, strand, segments, seq)."""
    out, cur = [], None
    with _open(path) as handle:
        for line in handle:
            if line.startswith(">"):
                head = line[1:].strip()
                rid, _, desc = head.partition(" ")
                chrom, strand, segs = parse_loc(_field(desc, "loc"))
                parents = {p for p in re.split(r"[,\s]", _field(desc, "parent")) if p.startswith("FBgn")}
                cur = {"id": rid, "name": _field(desc, "name"), "parent": parents,
                       "chrom": chrom, "strand": strand, "segments": segs,
                       "type": _field(desc, "type"), "seq": []}
                out.append(cur)
            elif keep_seq and cur is not None:
                cur["seq"].append(line.strip())
    for r in out:
        r["seq"] = "".join(r["seq"])
    return out


# ---------- вход из FASTA (данные организаторов или свои) ----------
def read_input_dir(path):
    """Папка с файлами <ген>.fasta (или .fa / .fna). В каждом файле:
         >dmel|<ген>|cds                         — CDS исследуемого гена (первая запись, обязательна)
         >dsim|<белок или ген>|ortholog          — CDS размеченного ортолога (необязательно)
         >dper|NW_020825322.1-:709401:710983      — участок генома вида с того же места (синтенный)
       Тип записи: метка cds/ortholog/region в третьем поле, иначе по двоеточию в id (как в файле статьи).
       Заголовки файла статьи (Section I) тоже подходят без изменений.
    -> {ген: {"raw": [...], "spaln": [], "genewise": []}} — та же структура, что read_unannotated_alignments."""
    import glob
    import os
    genes = collections.OrderedDict()
    files = sorted(sum((glob.glob(os.path.join(path, f"*.{e}")) for e in ("fasta", "fa", "fna")), []))
    for fn in files:
        recs, cur = [], None
        with _open(fn) as handle:
            for line in handle:
                line = line.strip()
                if not line:
                    continue
                if line.startswith(">"):
                    head = line[1:].split()[0]
                    parts = head.split("|")
                    tag = parts[2].lower() if len(parts) > 2 else ""
                    rec = parse_record_header(head)          # метки cds/ortholog/region парсер пропускает
                    if tag in ("cds", "ortholog"):
                        rec["annotated"] = True
                    elif tag == "region":
                        rec["annotated"] = False
                    rec["seq"] = ""
                    recs.append(rec)
                    cur = rec
                elif cur is not None:
                    cur["seq"] += line.upper()
        if not recs or recs[0]["species"] != "dmel":
            raise ValueError(f"{fn}: первая запись должна быть CDS гена D. melanogaster (>dmel|...)")
        recs[0]["annotated"] = True
        gene = recs[0]["id"]
        genes[gene] = {"raw": recs, "spaln": [], "genewise": []}
    return genes
