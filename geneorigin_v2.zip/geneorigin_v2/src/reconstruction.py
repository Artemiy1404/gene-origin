"""reconstruction.py — реконструкция эволюционных событий на месте гена.

Отвечает на вопрос кейса «какие замены, вставки и делеции связаны с формированием гена»
в три шага (метод сравнения перенесён из enabling.py / ancestral.py ТЗ 2–3):

1. Сравнение CDS D. melanogaster с последовательностью каждого вида (ортолог или участок без гена):
   локальное выравнивание с дорогими гэпами; гомология засчитывается, если счёт >= 1,5 × счёт
   с перемешанным участком. Наблюдения: кодон на месте ATG, стоп-кодоны в рамке гена, инделы,
   сдвиги рамки (с учётом компенсации), длина читаемой рамки.
2. Поляризация каждого события по дереву видов (парсимония на «лестничном» дереве линий):
     событие у ВСЕХ выровненных видов ближайшей внешней линии и ни у одного вида с геном
        -> предковое состояние; изменение произошло на ветви рождения Br_i (мутация рождения);
     событие только у видов ВНУТРИ группы с геном -> изменение после рождения (потеря/порча);
     событие только у части внешних видов -> изменение в их собственной линии, о рождении не говорит.
   Тип события: замена (какая буква на какую в кодоне), вставка или делеция (в линии dmel).
3. Предковые состояния (если есть IQ-TREE): дерево с ограничением по дереву видов, --ancestral;
   триплет в каждом узле на пути от корня к D. melanogaster с вероятностью; ветвь, где триплет
   впервые становится таким, как у гена.
Наблюдения (шаг 1) и интерпретации (шаги 2–3) возвращаются раздельно.
"""
import collections
import os
import random
import subprocess
from io import StringIO

from Bio import Phylo
from Bio.Align import PairwiseAligner
from Bio.Seq import Seq

from species import LINEAGE_INDEX, LINEAGES, SPECIES_NAMES

STOPS = {"TAA", "TAG", "TGA"}
# дерево 20 видов Acalyptratae (как в species.py); внутри L3 политомия
ACALYPTRATAE = ("((((((((((dmel,(dsim,dsec)),(dyak,dere)),dfic),(drho,dele,deug,dbia,dtak)),dkik),dana),"
                "(dmir,(dpse,dper))),dwil),sleb),(blat,bdor));")


def _aligner():
    a = PairwiseAligner()
    a.mode = "local"
    a.match_score, a.mismatch_score = 2, -3
    a.open_gap_score, a.extend_gap_score = -12, -2     # дорогие гэпы: меньше ложных сдвигов рамки
    return a


ALIGNER = _aligner()


# ---------------- шаг 1: сравнение гена с последовательностью вида ----------------
def best_alignment(cds, region):
    rc = str(Seq(region).reverse_complement())
    s_plus, s_minus = ALIGNER.score(cds, region), ALIGNER.score(cds, rc)
    strand, seq, score = ("+", region, s_plus) if s_plus >= s_minus else ("-", rc, s_minus)
    return score, strand, seq, ALIGNER.align(cds, seq)[0]


def null_score(cds, region, n=3, seed=42):
    rng, letters, best = random.Random(seed), list(region), 0.0
    for _ in range(n):
        rng.shuffle(letters)
        best = max(best, ALIGNER.score(cds, "".join(letters)))
    return best


def empty_comparison(note):
    """Нет данных для сравнения: не падаем, а возвращаем «недостаточно данных» для этого вида."""
    return {"score": 0.0, "null_score": 0.0, "strand": None, "coverage": 0.0, "identity": 0.0,
            "homologous": False, "insufficient": note, "start_triplet": None, "end_triplet": None,
            "stops_in_frame": [], "indels": [], "frameshifts": [], "orf_codons": 0, "expected_codons": 0,
            "orf_fraction": 0.0, "aligned_codons": [], "projected": ""}


def compare(cds, region, n_null=3, min_shift_nt=12, min_ratio=1.5, min_coverage=0.3):
    """Наблюдения: что на месте гена у вида. Позиции — в координатах CDS dmel (кодоны с 1)."""
    cds, region = cds.upper(), region.upper()
    n_codons = len(cds) // 3 - 1
    if sum(region.count(b) for b in "ACGT") < 30 or len(cds) < 9:
        return empty_comparison("участок пустой или почти весь из N — данных недостаточно")
    try:
        score, strand, seq, aln = best_alignment(cds, region)
    except (ValueError, IndexError) as e:
        return empty_comparison(f"выравнивание не построено ({type(e).__name__})")
    blocks_c, blocks_r = aln.aligned
    col, matches, shift = {}, 0, 0
    in_frame, indels, frameshifts = set(), [], []
    for i, ((c0, c1), (r0, r1)) in enumerate(zip(blocks_c, blocks_r)):
        c0, c1, r0, r1 = int(c0), int(c1), int(r0), int(r1)
        if i > 0:
            d = (r0 - int(blocks_r[i - 1][1])) - (c0 - int(blocks_c[i - 1][1]))
            if d:
                indels.append({"codon": c0 // 3 + 1, "cds_pos": c0 + 1, "length": d})
            shift += d
            if shift % 3 != 0:
                span, s, restored = 0, shift, False
                for j in range(i, len(blocks_c)):
                    if j > i:
                        s += (int(blocks_r[j][0]) - int(blocks_r[j - 1][1])) - \
                             (int(blocks_c[j][0]) - int(blocks_c[j - 1][1]))
                        if s % 3 == 0:
                            restored = True
                            break
                    span += int(blocks_c[j][1]) - int(blocks_c[j][0])
                if span >= min_shift_nt and (not frameshifts or frameshifts[-1]["until"] <= c0):
                    frameshifts.append({"codon": c0 // 3 + 1, "cds_pos": c0 + 1, "length": d,
                                        "out_of_frame_nt": span, "compensated": restored, "until": c0 + span})
        for k in range(c1 - c0):
            col[c0 + k] = r0 + k
            matches += cds[c0 + k] == seq[r0 + k]
            if shift % 3 == 0:
                in_frame.add(c0 + k)

    def triplet(c):
        if all(p in col for p in (c, c + 1, c + 2)) and col[c + 2] - col[c] == 2:
            return seq[col[c]:col[c] + 3]
        return None

    start = triplet(0)
    stop_pos = n_codons * 3
    end_triplet = triplet(stop_pos) if stop_pos + 2 < len(cds) else None
    stops = []
    for c in range(0, stop_pos, 3):
        t = triplet(c)
        if t in STOPS and c in in_frame:
            stops.append({"codon": c // 3 + 1, "gene": cds[c:c + 3], "species": t})
    anchor = next((c for c in range(0, stop_pos, 3) if triplet(c)), None)
    orf, expected = 0, 0
    if anchor is not None:
        expected = n_codons - anchor // 3
        p = col[anchor]
        while p + 3 <= len(seq) and seq[p:p + 3] not in STOPS:
            orf += 1
            p += 3
    coverage = len(col) / len(cds)
    null = null_score(cds, region, n_null) if coverage >= min_coverage else float(score)
    projected = "".join(seq[col[i]] if i in col else "-" for i in range(len(cds)))
    return {"score": float(score), "null_score": float(null), "strand": strand,
            "coverage": round(coverage, 3), "identity": round(matches / len(col), 3) if col else 0.0,
            "homologous": bool(coverage >= min_coverage and score >= min_ratio * null),
            "start_triplet": start, "end_triplet": end_triplet, "stops_in_frame": stops,
            "indels": indels,
            "frameshifts": [{k: v for k, v in f.items() if k != "until"} for f in frameshifts],
            "orf_codons": orf, "expected_codons": expected,
            "orf_fraction": round(min(1.0, orf / expected), 3) if expected else 0.0,
            "aligned_codons": sorted({p // 3 + 1 for p in col}), "projected": projected}


def _substitution(gene_t, sp_t):
    """'TAA' у вида против 'CAA' у гена -> 'T→C в 1-й позиции' (направление — от предка к гену)."""
    if not gene_t or not sp_t:
        return None
    diffs = [f"{a}→{b} в {i + 1}-й позиции" for i, (a, b) in enumerate(zip(sp_t, gene_t)) if a != b]
    return "; ".join(diffs) if diffs else None


# ---------------- шаг 2: поляризация по линиям ----------------
def events_of(species, r, cds):
    """Список событий вида (то, чем его последовательность отличается от гена)."""
    ev = []
    if r["start_triplet"] and r["start_triplet"] != "ATG":
        ev.append({"type": "start", "codon": 1, "species_triplet": r["start_triplet"], "gene_triplet": "ATG",
                   "kind": "замена", "detail": _substitution("ATG", r["start_triplet"])})
    for s in r["stops_in_frame"]:
        ev.append({"type": "stop", "codon": s["codon"], "species_triplet": s["species"], "gene_triplet": s["gene"],
                   "kind": "замена", "detail": _substitution(s["gene"], s["species"])})
    for f in r["frameshifts"]:
        if not f["compensated"]:
            ev.append({"type": "frameshift", "codon": f["codon"], "length": f["length"],
                       "kind": "делеция" if f["length"] > 0 else "вставка"})
    for d in r["indels"]:
        if d["length"] % 3 == 0:
            ev.append({"type": "indel3", "codon": d["codon"], "length": d["length"],
                       "kind": "делеция" if d["length"] > 0 else "вставка"})
    gene_end = cds[(len(cds) // 3 - 1) * 3:]
    if r["end_triplet"] and gene_end in STOPS and r["end_triplet"] not in STOPS:
        ev.append({"type": "stop_lost", "codon": len(cds) // 3, "species_triplet": r["end_triplet"],
                   "gene_triplet": gene_end, "kind": "замена", "detail": _substitution(gene_end, r["end_triplet"])})
    return ev


def _key(e):
    # инделы и сдвиги совпадают с точностью до 2 кодонов (выравнивание может сдвинуть разрыв)
    if e["type"] in ("frameshift", "indel3"):
        return (e["type"], (e["codon"] - 1) // 3, e.get("length"))
    return (e["type"], e["codon"])


def polarize(per_species, l0, gene_species):
    """Поляризация событий по «лестничному» дереву линий (парсимония).

    Для события берём выровненные на этом кодоне линии. Если событие несут ВСЕ выровненные линии,
    начиная с L_m и дальше, и ни одна более близкая, то у D. melanogaster состояние производное:
    изменение произошло в линии D. melanogaster на ветви Br_m (одно событие вместо многих).
      Br_m = ветвь рождения        -> birth: мутация, превратившая участок в ген;
      Br_m ближе ветви рождения    -> gene_change: ген изменился уже после рождения (напр. удлинение);
      Br_m дальше ветви рождения   -> before_birth: участок менялся ещё до рождения гена.
    Иначе событие — в собственной линии видов-носителей:
      носители внутри группы без гена -> loss; внутри группы с геном -> gene_variation;
      только внешние виды -> outgroup_lineage (о рождении не говорит).
    """
    present = sorted({LINEAGE_INDEX[s] for s in per_species if LINEAGE_INDEX.get(s) is not None})
    outgroups = [li for li in present if li > l0]
    birth = outgroups[0] if outgroups else None
    groups = collections.defaultdict(lambda: {"carriers": [], "example": None, "triplets": {}})
    covered = {s: set(r["aligned_codons"]) for s, r in per_species.items() if r["homologous"]}
    for s, r in per_species.items():
        if not r["homologous"]:
            continue
        for e in r["events"]:
            g = groups[_key(e)]
            g["carriers"].append(s)
            g["example"] = g["example"] or e
            if e.get("species_triplet"):
                g["triplets"][s] = e["species_triplet"]
    gene_species = set(gene_species)
    out = []
    for key, g in groups.items():
        e = g["example"]
        carriers = set(g["carriers"])
        aligned_here = {s for s, cods in covered.items() if e["codon"] in cods}
        lin = collections.defaultdict(lambda: [0, 0])          # линия -> [носителей, выровнено]
        for sp in aligned_here:
            li = LINEAGE_INDEX[sp]
            lin[li][1] += 1
            lin[li][0] += sp in carriers
        full = sorted(li for li, (c, n) in lin.items() if c == n and n > 0)
        none = sorted(li for li, (c, n) in lin.items() if c == 0)
        mixed = sorted(li for li, (c, n) in lin.items() if 0 < c < n)
        m = min(full) if full else None
        suffix = m is not None and not mixed and all(li < m for li in none)
        branch = None
        if suffix:
            branch = f"Br{m}"
            if birth is not None and m == birth:
                role = "birth"
            elif m <= l0:
                role = "gene_change"
            else:
                role = "before_birth"
        elif carriers <= gene_species:
            role = "gene_variation"
        elif all(LINEAGE_INDEX.get(s, 99) <= l0 for s in carriers):
            role = "loss"
        else:
            role = "outgroup_lineage"
        n_carrier_lineages = len(full) if suffix else len({LINEAGE_INDEX[s] for s in carriers})
        # одна линия-носитель не поляризует: замена «у предка» и «в линии вида» одинаково экономны
        polarized = suffix and n_carrier_lineages >= 2
        if suffix and not polarized and role in ("gene_change", "before_birth"):
            role = "gene_variation" if carriers <= gene_species else "outgroup_lineage"
            branch = None
        if e["type"] == "indel3" and role in ("gene_variation", "loss", "outgroup_lineage"):
            continue                                   # инделы без сдвига рамки у отдельных видов — шум
        # Состояние «не ATG / стоп / не стоп» общее, но триплеты у носителей могут быть разными
        # (ATA у одного, ATT у другого): тогда это разные замены, и одну замену мы не называем.
        trip = g["triplets"]
        e = dict(e)
        if len(set(trip.values())) > 1:
            e["species_triplet"] = None
            e["detail"] = None
        out.append({**e, "carriers": sorted(carriers), "aligned_species": sorted(aligned_here),
                    "carrier_triplets": dict(sorted(trip.items())),
                    "role": role, "branch": branch, "carrier_lineages": n_carrier_lineages,
                    "polarized": bool(polarized), "mixed_lineages": mixed,
                    "support": (f"подтверждено {n_carrier_lineages} линиями" if polarized else
                                ("только одна внешняя линия выровнена — не поляризовано" if role == "birth" else ""))})
    order = {"birth": 0, "before_birth": 1, "gene_change": 2, "loss": 3, "gene_variation": 4, "outgroup_lineage": 5}
    return sorted(out, key=lambda x: (order[x["role"]], x["codon"]))


ROLE_RU = {"birth": "мутация рождения", "before_birth": "изменение участка до рождения гена",
           "gene_change": "изменение гена после рождения (в линии D. melanogaster)",
           "loss": "порча/потеря гена в отдельной линии", "gene_variation": "различие между ортологами",
           "outgroup_lineage": "изменение в линии внешнего вида"}


def describe(ev):
    """Фраза о событии. Для событий в линии D. melanogaster направление «предок -> ген»."""
    sp = ", ".join(SPECIES_NAMES.get(s, s) for s in ev["carriers"][:3]) + (" и др." if len(ev["carriers"]) > 3 else "")
    # направление «предок -> ген» называем только для поляризованных событий (>= 2 линии-носителя)
    anc = ev["role"] in ("birth", "before_birth", "gene_change") and ev.get("polarized")
    who = "у предка" if anc else "у внешнего вида" if ev["role"] in ("birth", "before_birth", "outgroup_lineage") else "у вида"
    trip = ev.get("species_triplet")
    if not trip and ev.get("carrier_triplets"):
        trip = " / ".join(f"{t} ({SPECIES_NAMES.get(s, s)})" for s, t in ev["carrier_triplets"].items())
    det = f" ({ev['detail']})" if ev.get("detail") else ""
    if ev["type"] == "start":
        what = f"старт: {who} {trip}, у гена ATG{det}"
    elif ev["type"] == "stop":
        what = f"кодон {ev['codon']}: {who} стоп {trip}, у гена {ev['gene_triplet']}{det}"
    elif ev["type"] == "stop_lost":
        what = f"конец гена: {who} {trip} вместо стопа {ev['gene_triplet']}{det}"
    elif ev["type"] == "frameshift":
        n = abs(ev["length"])
        if anc:
            what = f"кодон {ev['codon']}: сдвиг рамки снят; в линии гена {ev['kind']} {n} н."
        elif ev["role"] == "birth":
            what = (f"кодон {ev['codon']}: различие на {n} н., сдвигающее рамку "
                    f"(возможная {ev['kind']} в линии гена; направление не установлено)")
        else:
            what = f"кодон {ev['codon']}: сдвиг рамки у вида ({'вставка' if ev['length'] > 0 else 'делеция'} {n} н.)"
    else:
        n = abs(ev["length"])
        if anc:
            what = f"кодон {ev['codon']}: в линии гена {ev['kind']} {n} н. без сдвига рамки"
        elif ev["role"] == "birth":
            what = f"кодон {ev['codon']}: различие на {n} н. без сдвига рамки (направление не установлено)"
        else:
            what = f"кодон {ev['codon']}: у вида {'вставка' if ev['length'] > 0 else 'делеция'} {n} н. без сдвига рамки"
    tail = (f"на ветви {ev['branch']}; " if ev.get("branch") else "") + f"носители: {sp}"
    label = ROLE_RU[ev["role"]]
    if ev["role"] == "birth" and not ev.get("polarized"):
        label = "кандидат в мутацию рождения"
    return f"{label} — {what}; {tail}" + (f" ({ev['support']})" if ev.get("support") else "")


# ---------------- шаг 3: предковые состояния (IQ-TREE) ----------------
def pruned_tree(species):
    tree = Phylo.read(StringIO(ACALYPTRATAE), "newick")
    for tip in list(tree.get_terminals()):
        if tip.name not in species:
            tree.prune(tip)
    buf = StringIO()
    Phylo.write(tree, buf, "newick", plain=True)
    return buf.getvalue().strip()


def ancestral(cds, per_species, codons, workdir, iqtree="iqtree2", seed=42):
    """Триплеты на месте codons вдоль пути корень -> dmel, с вероятностями."""
    seqs = collections.OrderedDict(dmel=cds.upper())
    for s, r in per_species.items():
        if r["homologous"] and s in LINEAGE_INDEX:
            seqs[s] = r["projected"]
    if len(seqs) < 4:
        return {"status": "мало гомологичных последовательностей (< 4)"}
    os.makedirs(workdir, exist_ok=True)
    aln = os.path.join(workdir, "gene_coords.aln.fasta")
    with open(aln, "w") as f:
        for s, q in seqs.items():
            f.write(f">{s}\n{q}\n")
    prefix = os.path.join(workdir, "asr")
    with open(prefix + ".constraint.nwk", "w") as f:
        f.write(pruned_tree(list(seqs)) + "\n")
    try:
        subprocess.run([iqtree, "-s", aln, "-g", prefix + ".constraint.nwk", "-m", "MFP", "--ancestral",
                        "--seed", str(seed), "-T", "1", "--prefix", prefix, "-redo", "-quiet"],
                       check=True, capture_output=True, text=True, timeout=600)
    except Exception as e:                                                      # noqa: BLE001
        return {"status": f"IQ-TREE не запустился: {type(e).__name__}"}
    states = collections.defaultdict(dict)
    with open(prefix + ".state") as f:
        head = None
        for line in f:
            if line.startswith("#"):
                continue
            parts = line.rstrip("\n").split("\t")
            if parts[0] == "Node":
                head = parts
                continue
            rec = dict(zip(head, parts))
            probs = {b: float(rec.get(f"p_{b}", 0)) for b in "ACGT"}
            states[rec["Node"]][int(rec["Site"]) - 1] = (rec["State"], max(probs.values()))
    tree = Phylo.read(prefix + ".treefile", "newick")
    far = max((s for s in seqs if s != "dmel"), key=lambda s: LINEAGE_INDEX.get(s, -1))
    tree.root_with_outgroup(far)
    path = [c for c in tree.get_path("dmel") if c.name in states]
    hist = {}
    for codon in codons:
        cols = [(codon - 1) * 3 + k for k in range(3)]
        if cols[-1] >= len(cds):
            continue
        steps = []
        for n in path:
            trip = "".join(states[n.name].get(x, ("-", 0))[0] for x in cols)
            prob = 1.0
            for x in cols:
                prob *= states[n.name].get(x, ("-", 0))[1]
            tips = sorted(t.name for t in n.get_terminals())
            steps.append({"node": n.name, "tips": tips, "triplet": trip, "prob": round(prob, 3),
                          "max_lineage": max(LINEAGE_INDEX.get(t, -1) for t in tips)})
        gene_t = cds.upper()[cols[0]:cols[-1] + 1]
        steps.append({"node": "dmel", "tips": ["dmel"], "triplet": gene_t, "prob": 1.0, "max_lineage": -1})
        change = None
        for a, b in zip(steps, steps[1:]):
            if a["triplet"] != b["triplet"] and b["triplet"] == gene_t:
                change = {"from": a["triplet"], "to": b["triplet"], "branch": f"Br{b['max_lineage'] + 1}",
                          "prob_from": a["prob"]}
        hist[codon] = {"along_lineage": steps, "change_to_gene_state": change,
                       "in_species": {s: q[cols[0]:cols[-1] + 1] for s, q in seqs.items()}}
    model = ""
    for line in open(prefix + ".iqtree"):
        if line.startswith("Best-fit model"):
            model = line.split(":")[1].strip()
    return {"status": "ok", "model": model, "outgroup": far, "codons": hist, "alignment": aln,
            "treefile": prefix + ".treefile"}


# ---------------- всё вместе ----------------
def reconstruct(gene_records, regions, l0, cfg, workdir=None, iqtree=None):
    """gene_records — запись гена из файла выравниваний (raw), regions — regions.classify_species."""
    rc = cfg.get("reconstruction", {})
    dmel = next(r for r in gene_records["raw"] if r["species"] == "dmel" and r["annotated"])
    cds = dmel["seq"]
    per = {}
    for r in gene_records["raw"]:
        sp = r["species"]
        if sp == "dmel" or sp not in LINEAGE_INDEX:
            continue
        res = compare(cds, r["seq"], n_null=rc.get("n_null", 3))
        res["record"] = r["id"]
        res["annotated"] = r["annotated"]
        if sp not in per or res["score"] > per[sp]["score"]:
            per[sp] = res
    for sp, r in per.items():
        r["events"] = events_of(sp, r, cds) if r["homologous"] else []
    gene_species = [s for s, v in regions["species"].items() if v["status"].startswith("gene_")]
    pol = polarize(per, l0, gene_species)
    def ranges(cods):
        out, start, prev = [], None, None
        for c in cods:
            if start is None:
                start = prev = c
            elif c == prev + 1:
                prev = c
            else:
                out.append([start, prev])
                start = prev = c
        if start is not None:
            out.append([start, prev])
        return out
    out = {"cds": cds, "per_species": {s: {**{k: v for k, v in r.items() if k != "aligned_codons"},
                                             "aligned_ranges": ranges(r["aligned_codons"])}
                                          for s, r in per.items()},
           "events": pol, "n_homologous": sum(r["homologous"] for r in per.values())}
    if iqtree and workdir and rc.get("ancestral", True):
        key_codons = sorted({1, len(cds) // 3} | {e["codon"] for e in pol if e["type"] in ("start", "stop", "stop_lost")})
        out["ancestral"] = ancestral(cds, per, key_codons, workdir, iqtree, cfg.get("seed", 42))
    return out
