"""report.py — HTML-отчёт по гену и сводная страница (без внешних зависимостей, SVG рисуется вручную).

Отчёт гена: вердикт; путь по дереву решений; «что лежит на месте гена» у каждого вида
(рисунок с поломками); выравнивание вокруг ключевых кодонов; реконструкция событий и предковые
кодоны; ветка дупликации с деревом; улики (наблюдения отдельно от интерпретаций).
Запуск отдельно: python src/report.py results    (перестроит отчёты по всем evidence.json)
"""
import glob
import html
import json
import os
import sys
from io import StringIO

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from species import LINEAGES, SPECIES_NAMES, LINEAGE_INDEX   # noqa: E402

STOPS = {"TAA", "TAG", "TGA"}
VERDICT_RU = {"de_novo": "de novo", "duplication": "дупликация", "ancient": "древний ген",
              "insufficient_data": "недостаточно данных", "other": "иной механизм"}
SUBTYPE_RU = {"intergenic": "межгенный участок", "nested_in_intron": "в интроне другого гена",
              "overlapping_exon": "перекрывает экзон другого гена", "context_unknown": "положение в геноме неизвестно",
              "family_duplicated_after_birth": "семейство возникло de novo, потом удвоилось",
              "parent_of_later_duplicate": "исходная копия семейства; копия появилась позже",
              "retrocopy": "ретрокопия (несёт соединённые экзоны родителя)",
              "putative_retrocopy": "предполагаемая ретрокопия",
              "dna_duplication": "копия через ДНК (интроны на тех же местах)",
              "mechanism_unresolved": "механизм дупликации не уточнён",
              "direction_unresolved": "направление не определено",
              "parent_of_duplicate": "родитель копии", "ortholog_in_farthest_lineage": "ген есть у самой дальней линии",
              "homolog_beyond_origin": "гомолог у видов дальше ветви рождения (положение не проверено)",
              "homolog_outside_synteny": "гомолог у видов дальше ветви рождения",
              "homolog_in_distant_species": "гомолог у далёких видов",
              "outgroup_unalignable": "предковый участок не выравнивается", "no_syntenic_data": "нет синтенных данных",
              "weak_likelihood": "слабое правдоподобие"}
CONF_RU = {"high": "высокая", "medium": "средняя", "low": "низкая", "none": "—"}
STATUS_RU = {"gene_annotated": "размеченный ген", "gene_unannotated_intact": "неразмеченная целая рамка",
             "gene_unannotated_defective": "похоже на ген, рамка с поломками",
             "noncoding": "нет значимого сходства с геном"}
TYPE_RU = {"start": "старт", "stop": "стоп", "stop_lost": "конец гена", "frameshift": "сдвиг рамки",
           "indel3": "индел без сдвига"}
GRADE_RU = {"dna": "ДНК выравнивается", "trace": "слабый след", "synteny_only": "только синтения"}
ROLE_RU = {"birth": "мутация рождения", "before_birth": "до рождения", "gene_change": "после рождения",
           "loss": "потеря", "gene_variation": "между ортологами", "outgroup_lineage": "линия внешнего вида"}

CSS = """
:root{
  /* Лабораторный журнал: спокойная бумага, чернила, нуклеотидная палитра как в выравнивателях */
  --bg:#f6f7f5; --surface:#ffffff; --ink:#1d2427; --muted:#5c676d; --rule:#d9dedb; --soft:#eef1ef;
  --accent:#24557a;
  --v-denovo:#1d7a5c; --v-dup:#6b47a6; --v-anc:#8a6420; --v-ins:#6f777d;
  --gene:#1d7a5c; --gene-weak:#7fb8a3; --nc-dna:#b45f2b; --nc-trace:#e0a77c; --nc-syn:#c9cfcc;
  --nt-a:#2f8a3a; --nt-c:#2c63b0; --nt-g:#a8730c; --nt-t:#c2373b; --stop-bg:#f7d9d6; --start-bg:#d6eedf;
  --f-text:"IBM Plex Sans",-apple-system,"Segoe UI",Roboto,Arial,sans-serif;
  --f-mono:"IBM Plex Mono",ui-monospace,Menlo,Consolas,monospace;
}
@media (prefers-color-scheme: dark){:root:not([data-theme="light"]){
  --bg:#14191b; --surface:#1b2124; --ink:#e3e8e6; --muted:#9aa6a2; --rule:#2e373a; --soft:#222a2d;
  --accent:#7fb3dc; --v-denovo:#5cc49c; --v-dup:#b39ae6; --v-anc:#d8ad5e; --v-ins:#a2abb0;
  --gene:#4fb893; --gene-weak:#2f6e58; --nc-dna:#e08a52; --nc-trace:#8a5a3a; --nc-syn:#3d474a;
  --nt-a:#6cc777; --nt-c:#7aa8ec; --nt-g:#e0b14e; --nt-t:#f07a7c; --stop-bg:#4a2624; --start-bg:#1f4232; color-scheme:dark}}
:root[data-theme="dark"]{
  --bg:#14191b; --surface:#1b2124; --ink:#e3e8e6; --muted:#9aa6a2; --rule:#2e373a; --soft:#222a2d;
  --accent:#7fb3dc; --v-denovo:#5cc49c; --v-dup:#b39ae6; --v-anc:#d8ad5e; --v-ins:#a2abb0;
  --gene:#4fb893; --gene-weak:#2f6e58; --nc-dna:#e08a52; --nc-trace:#8a5a3a; --nc-syn:#3d474a;
  --nt-a:#6cc777; --nt-c:#7aa8ec; --nt-g:#e0b14e; --nt-t:#f07a7c; --stop-bg:#4a2624; --start-bg:#1f4232; color-scheme:dark}
*{box-sizing:border-box}
body{background:var(--bg);color:var(--ink);font:15px/1.55 var(--f-text);margin:0}
.wrap{max-width:980px;margin:0 auto;padding-block:28px 64px;
  padding-left:max(16px,env(safe-area-inset-left,0px));padding-right:max(16px,env(safe-area-inset-right,0px))}
h1{font-size:28px;line-height:1.2;margin:0;font-weight:600;text-wrap:balance}
h2{font-size:18px;margin:0 0 10px;font-weight:600;text-wrap:balance}
h3{font-size:14px;margin:14px 0 6px;font-weight:600;color:var(--muted);text-transform:uppercase;letter-spacing:.06em}
p{margin:0 0 8px;max-width:72ch}
a{color:var(--accent)}
a:focus-visible,button:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
section{background:var(--surface);border:1px solid var(--rule);border-radius:6px;padding:18px 20px;display:flex;flex-direction:column;gap:6px}
.stack{display:flex;flex-direction:column;gap:16px;margin-top:20px}
.head{display:flex;flex-wrap:wrap;gap:12px 24px;align-items:flex-end;justify-content:space-between}
.id{font:13px var(--f-mono);color:var(--muted)}
.chip{display:inline-flex;align-items:center;gap:6px;font-weight:600;font-size:13px;padding:3px 10px;border-radius:999px;
  border:1.5px solid currentColor;white-space:nowrap}
.v-de_novo{color:var(--v-denovo)} .v-duplication{color:var(--v-dup)} .v-ancient{color:var(--v-anc)}
.v-insufficient_data,.v-other{color:var(--v-ins)}
.facts{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:8px 18px;margin-top:14px}
.facts div{min-width:0} .facts dt{font-size:12px;color:var(--muted);text-transform:uppercase;letter-spacing:.05em}
.facts dd{margin:0;font-weight:600;font-variant-numeric:tabular-nums}
ol.path{margin:0;padding:0;list-style:none;counter-reset:s;display:flex;flex-direction:column;gap:6px}
ol.path li{display:grid;grid-template-columns:44px 1fr;gap:10px;align-items:baseline}
ol.path .n{font:600 12px var(--f-mono);color:var(--accent)}
ol.path .q{color:var(--muted);font-size:13px} ol.path .a{font-weight:500}
.scroll{overflow-x:auto;max-width:100%}
svg text{font-family:var(--f-text)}
table{border-collapse:collapse;font-size:13px;width:100%}
th,td{text-align:left;padding:5px 8px;border-bottom:1px solid var(--rule);vertical-align:top}
th{font-size:12px;color:var(--muted);font-weight:600}
td.num{font-variant-numeric:tabular-nums;text-align:right}
.aln{font:12px/1.35 var(--f-mono);border-collapse:separate;border-spacing:0;width:auto}
.aln td{padding:2px 5px;border:0;white-space:nowrap}
.aln td.sp{font-family:var(--f-text);color:var(--muted);padding-right:12px}
.aln td.key{background:var(--soft);border-left:1px solid var(--accent);border-right:1px solid var(--accent)}
.aln th{font:11px var(--f-mono);color:var(--muted);border:0;padding:2px 5px;text-align:left}
.b-A{color:var(--nt-a)} .b-C{color:var(--nt-c)} .b-G{color:var(--nt-g)} .b-T{color:var(--nt-t)}
.same{color:var(--muted);opacity:.55} .gap{color:var(--muted)}
.t-stop{background:var(--stop-bg);border-radius:3px} .t-start{background:var(--start-bg);border-radius:3px}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:18px} .cols>div{min-width:0}
@media (max-width:720px){.cols{grid-template-columns:1fr}}
ul.ev{margin:0;padding-left:18px;display:flex;flex-direction:column;gap:4px;font-size:14px}
ul.ev .st{font:11px var(--f-mono);color:var(--muted)}
.role{font:600 11px var(--f-text);padding:1px 7px;border-radius:999px;background:var(--soft);white-space:nowrap}
.role.birth{background:var(--start-bg)} .role.loss{background:var(--stop-bg)}
.legend{display:flex;flex-wrap:wrap;gap:6px 16px;font-size:12px;color:var(--muted)}
.legend i{display:inline-block;width:14px;height:9px;border-radius:2px;margin-right:5px;vertical-align:middle}
.chain{display:flex;flex-wrap:wrap;gap:4px;align-items:center;font:12px var(--f-mono)}
.chain span.node{padding:2px 6px;border:1px solid var(--rule);border-radius:4px}
.chain span.node.ch{border-color:var(--accent);font-weight:600}
.chain small{color:var(--muted);font-family:var(--f-text)}
.note{font-size:13px;color:var(--muted)}
footer{margin-top:22px;font-size:12px;color:var(--muted)}
.filters{display:flex;flex-wrap:wrap;gap:8px;margin:14px 0}
.filters button{font:13px var(--f-text);padding:4px 12px;border-radius:999px;border:1px solid var(--rule);background:var(--surface);color:var(--ink);cursor:pointer}
.filters button[aria-pressed="true"]{border-color:var(--accent);color:var(--accent);font-weight:600}
@media (prefers-reduced-motion:reduce){*{transition:none!important}}
"""

FONTS = ('<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=IBM+Plex+Mono:wght@400;600'
         '&family=IBM+Plex+Sans:wght@400;500;600&display=swap">')


def esc(x):
    return html.escape(str(x), quote=True)


def page(title, body, full=True):
    head = (f'<title>{esc(title)}</title>\n<meta name="claude:viewport-fit-sides" content="cover">\n'
            f'{FONTS}\n<style>{CSS}</style>\n')
    if not full:
        return head + body
    return ('<!doctype html>\n<html lang="ru"><head><meta charset="utf-8">\n'
            '<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">\n'
            + head + '</head><body>\n' + body + '\n</body></html>\n')


def sp_label(sp):
    return SPECIES_NAMES.get(sp, sp)


# ---------- рисунок: что лежит на месте гена ----------
def species_figure(ev):
    rec = ev.get("reconstruction") or {}
    per = rec.get("per_species") or {}
    st = ev.get("species_status") or {}
    cds = rec.get("cds") or ""
    n = len(cds) // 3
    if not n or not st:
        return '<p class="note">Нет синтенных данных для рисунка.</p>'
    rows = ["dmel"] + sorted(st, key=lambda s: (st[s]["lineage"], s))
    left, right, top, rh = 170, 744, 34, 22
    W = 760
    H = top + rh * len(rows) + 46 + 18
    x = lambda c: left + (right - left) * (c - 1) / max(1, n - 1)  # noqa: E731
    out = [f'<svg viewBox="0 0 {W} {H}" width="{W}" role="img" aria-label="Что лежит на месте гена у каждого вида" '
           f'style="max-width:none">']
    out.append(f'<text x="{left}" y="18" font-size="12" fill="var(--muted)">кодоны гена D. melanogaster, 1–{n}</text>')
    l0 = ev.get("l0")
    sep_done, shift = False, 0
    for i, sp in enumerate(rows):
        li = -1 if sp == "dmel" else st[sp]["lineage"]
        if l0 is not None and not sep_done and li > l0:
            sep_done, shift = True, 18
            ys = top + i * rh + 6
            out.append(f'<line x1="8" x2="{right}" y1="{ys}" y2="{ys}" stroke="var(--accent)" stroke-dasharray="5 4"/>')
            out.append(f'<text x="{left}" y="{ys - 4}" font-size="11" fill="var(--accent)">'
                       f'ниже — виды без гена · ветвь рождения {esc(ev.get("origin_branch") or "")}</text>')
        y = top + i * rh + shift
        name = "D. melanogaster" if sp == "dmel" else sp_label(sp)
        lin = "" if sp == "dmel" else LINEAGES[li][0] if 0 <= li < len(LINEAGES) else ""
        out.append(f'<text x="8" y="{y + 14}" font-size="12" font-style="italic" fill="var(--ink)">{esc(name)}</text>')
        out.append(f'<text x="138" y="{y + 14}" font-size="10" fill="var(--muted)">{lin}</text>')
        out.append(f'<line x1="{left}" x2="{right}" y1="{y + 10}" y2="{y + 10}" stroke="var(--rule)"/>')
        if sp == "dmel":
            out.append(f'<rect x="{left}" y="{y + 4}" width="{right - left}" height="12" rx="2" fill="var(--gene)"/>')
            continue
        s = st[sp]
        status, grade = s["status"], s.get("grade")
        fill = {"gene_annotated": "var(--gene)", "gene_unannotated_intact": "var(--gene)",
                "gene_unannotated_defective": "var(--gene-weak)"}.get(status) or \
            {"dna": "var(--nc-dna)", "trace": "var(--nc-trace)"}.get(grade, "var(--nc-syn)")
        r = per.get(sp)
        if r and r.get("homologous"):
            for a, b in r.get("aligned_ranges", []):
                out.append(f'<rect x="{x(a):.1f}" y="{y + 4}" width="{max(2, x(b) - x(a)):.1f}" height="12" rx="2" fill="{fill}"/>')
            for stp in r.get("stops_in_frame", []):
                cx = x(stp["codon"])
                out.append(f'<rect x="{cx - 1.5:.1f}" y="{y + 1}" width="3" height="18" fill="var(--nt-t)">'
                           f'<title>стоп {esc(stp["species"])} в кодоне {stp["codon"]}</title></rect>')
            for f in r.get("frameshifts", []):
                if f.get("compensated"):
                    continue
                cx = x(f["codon"])
                out.append(f'<path d="M{cx - 5:.1f} {y + 20} L{cx + 5:.1f} {y + 20} L{cx:.1f} {y + 13} Z" fill="var(--nt-c)">'
                           f'<title>сдвиг рамки в кодоне {f["codon"]} ({f["length"]:+d} н.)</title></path>')
            stt = r.get("start_triplet")
            if stt and stt != "ATG":
                out.append(f'<text x="{left - 4}" y="{y + 14}" font-size="10" text-anchor="end" '
                           f'font-family="var(--f-mono)" fill="var(--nt-t)">{esc(stt)}</text>')
            elif not stt:
                out.append(f'<text x="{left - 4}" y="{y + 14}" font-size="10" text-anchor="end" '
                           f'font-family="var(--f-mono)" fill="var(--muted)">?<title>позиция старта не выровнена</title></text>')
        else:
            out.append(f'<rect x="{left}" y="{y + 4}" width="{right - left}" height="12" rx="2" fill="none" '
                       f'stroke="{fill}" stroke-dasharray="3 3"/>')
    yb = top + rh * len(rows) + 6 + (18 if sep_done else 0)
    step = 25 if n <= 200 else 50 if n <= 500 else 100
    ticks = [1] + list(range(step, n + 1, step))
    for c in ticks:
        out.append(f'<line x1="{x(c):.1f}" x2="{x(c):.1f}" y1="{yb}" y2="{yb + 5}" stroke="var(--muted)"/>'
                   f'<text x="{x(c):.1f}" y="{yb + 18}" font-size="10" text-anchor="middle" fill="var(--muted)">{c}</text>')
    out.append("</svg>")
    legend = ('<div class="legend"><span><i style="background:var(--gene)"></i>ген</span>'
              '<span><i style="background:var(--gene-weak)"></i>похоже на ген, с поломками</span>'
              '<span><i style="background:var(--nc-dna)"></i>не ген, ДНК выравнивается</span>'
              '<span><i style="background:var(--nc-trace)"></i>не ген, слабый след</span>'
              '<span><i style="border:1px dashed var(--muted)"></i>место только по синтении</span>'
              '<span><i style="background:var(--nt-t);width:4px"></i>стоп в рамке гена</span>'
              '<span>▲ сдвиг рамки</span><span style="font-family:var(--f-mono);color:var(--nt-t)">ATA</span>'
              '<span>кодон на месте ATG</span></div>')
    return f'<div class="scroll">{"".join(out)}</div>{legend}'


# ---------- выравнивание вокруг ключевых кодонов ----------
def alignment_windows(ev, max_windows=4, flank=4):
    rec = ev.get("reconstruction") or {}
    per = rec.get("per_species") or {}
    cds = (rec.get("cds") or "").upper()
    n = len(cds) // 3
    if not n:
        return ""
    keys = [1]
    for e in rec.get("events", []):
        if e["role"] in ("birth", "before_birth", "gene_change") and e["codon"] not in keys:
            keys.append(e["codon"])
    for sp, r in per.items():
        if not r.get("homologous"):
            continue
        for s in r.get("stops_in_frame", []):
            if s["codon"] not in keys:
                keys.append(s["codon"])
    keys = keys[:max_windows]
    seqs = [("dmel", cds)] + [(sp, r["projected"]) for sp, r in
                              sorted(per.items(), key=lambda kv: (LINEAGE_INDEX.get(kv[0], 99), kv[0]))
                              if r.get("homologous") and r.get("projected")]
    blocks = []
    for k in keys:
        lo, hi = max(1, k - flank), min(n, k + flank)
        head = "".join(f'<th>{c}</th>' for c in range(lo, hi + 1))
        body = []
        for sp, q in seqs:
            cells = []
            for c in range(lo, hi + 1):
                t = q[(c - 1) * 3:(c - 1) * 3 + 3]
                ref = cds[(c - 1) * 3:(c - 1) * 3 + 3]
                cls = "t-stop" if t in STOPS and not (sp == "dmel" and c == n) else ("t-start" if t == "ATG" and c == 1 else "")
                bases = "".join(
                    f'<span class="gap">-</span>' if b == "-" else
                    (f'<span class="same">{b}</span>' if sp != "dmel" and b == rb else f'<span class="b-{b}">{b}</span>')
                    for b, rb in zip(t.ljust(3, "-"), ref.ljust(3, "-")))
                cells.append(f'<td class="{"key " if c == k else ""}"><span class="{cls}">{bases}</span></td>')
            name = "D. melanogaster" if sp == "dmel" else sp_label(sp)
            body.append(f'<tr><td class="sp"><i>{esc(name)}</i></td>{"".join(cells)}</tr>')
        title = "старт-кодон" if k == 1 else f"кодон {k}"
        blocks.append(f'<h3>{title}</h3><div class="scroll"><table class="aln"><tr><th></th>{head}</tr>'
                      f'{"".join(body)}</table></div>')
    return ('<p class="note">Последовательности видов спроецированы на координаты гена. Блёклые буквы совпадают '
            'с D. melanogaster, цветные — отличаются; красный фон — стоп-кодон, зелёный — ATG.</p>' + "".join(blocks))


# ---------- реконструкция ----------
def events_table(ev):
    rec = ev.get("reconstruction") or {}
    evs = rec.get("events") or []
    if not rec:
        return ""
    rows = []
    for e in evs:
        txt = next((x["text"] for x in ev.get("evidence", []) if x.get("step") == "reconstruction"
                    and x.get("codon") == e["codon"] and x.get("role") == e["role"]), "")
        label = ROLE_RU[e["role"]] + ("" if e["role"] != "birth" or e.get("polarized") else " (кандидат)")
        rows.append(f'<tr><td><span class="role {e["role"]}">{esc(label)}</span></td><td class="num">{e["codon"]}</td>'
                    f'<td>{esc(e.get("kind", ""))}</td><td>{esc(e.get("branch") or "—")}</td>'
                    f'<td>{esc(txt.split(" — ", 1)[-1] if txt else "")}</td></tr>')
    table = ('<div class="scroll"><table><tr><th>Роль</th><th>Кодон</th><th>Тип</th><th>Ветвь</th><th>Событие</th></tr>'
             + "".join(rows) + '</table></div>') if rows else \
        '<p>Событий, которые различали бы ген и участки других видов, не найдено (или участки не выравниваются).</p>'
    a = rec.get("ancestral") or {}
    asr = ""
    if a.get("status") == "ok":
        parts = []
        for codon, h in a["codons"].items():
            ch = h.get("change_to_gene_state")
            chain = []
            steps = h["along_lineage"]
            for i, s in enumerate(steps):
                lab = "dmel" if s["node"] == "dmel" else f"до L{s['max_lineage']}" if s["max_lineage"] >= 0 else s["node"]
                changed = i > 0 and steps[i - 1]["triplet"] != s["triplet"]
                chain.append(f'<span class="node{" ch" if changed else ""}" title="{esc(", ".join(s["tips"]))}">'
                             f'{esc(s["triplet"])} <small>{esc(lab)} · {s["prob"]:.2f}</small></span>')
            note = (f' — изменение {esc(ch["from"])}→{esc(ch["to"])} на ветви {esc(ch["branch"])}' if ch else
                    " — у всех предков то же, что у гена")
            parts.append(f'<div><b>кодон {codon}</b>{note}<div class="chain">{" → ".join(chain)}</div></div>')
        asr = (f'<h3>Предковые кодоны (IQ-TREE, {esc(a.get("model", ""))}, дерево видов как ограничение)</h3>'
               '<p class="note">Путь от корня к D. melanogaster; «до Lk» — узел, объединяющий D. melanogaster '
               'с линиями до Lk; число — вероятность триплета.</p>' + "".join(parts))
    elif a:
        asr = f'<p class="note">Предковые кодоны: {esc(a.get("status"))}.</p>'
    return table + asr


# ---------- дупликация ----------
def tree_svg(newick, highlight=()):
    from Bio import Phylo
    try:
        t = Phylo.read(StringIO(newick), "newick")
    except Exception:                                                           # noqa: BLE001
        return ""
    leaves = t.get_terminals()
    ys = {leaf: i for i, leaf in enumerate(leaves)}
    depth = t.depths(unit_branch_lengths=True)
    maxd = max(depth.values()) or 1
    W, rh, left, right = 760, 22, 16, 560
    X = lambda c: left + (right - left) * depth[c] / maxd   # noqa: E731

    def y(c):
        if c in ys:
            return 14 + ys[c] * rh
        return sum(y(ch) for ch in c.clades) / len(c.clades)
    out = [f'<svg viewBox="0 0 {W} {len(leaves) * rh + 20}" width="{W}" role="img" aria-label="Дерево семейства" style="max-width:none;min-width:620px;width:100%">']
    for c in t.find_clades(order="preorder"):
        for ch in c.clades:
            out.append(f'<path d="M{X(c):.1f} {y(ch):.1f} H{X(ch):.1f}" stroke="var(--muted)" fill="none"/>')
        if c.clades:
            out.append(f'<path d="M{X(c):.1f} {y(c.clades[0]):.1f} V{y(c.clades[-1]):.1f}" stroke="var(--muted)" fill="none"/>')
            if c.confidence is not None or c.name:
                lab = c.name if c.name else str(c.confidence)
                out.append(f'<text x="{X(c) + 3:.1f}" y="{y(c) - 3:.1f}" font-size="10" fill="var(--muted)">{esc(lab)}</text>')
        else:
            hl = any(h in (c.name or "") for h in highlight)
            out.append(f'<text x="{X(c) + 6:.1f}" y="{y(c) + 4:.1f}" font-size="12" fill="var(--ink)"'
                       f'{" font-weight=\"600\"" if hl else ""}>{esc(c.name)}</text>')
    out.append("</svg>")
    return f'<div class="scroll">{"".join(out)}</div>'


def duplication_block(ev):
    d = ev.get("duplication")
    if not d:
        return ""
    names = d.get("names", {})
    lab = {"distribution": "распространение по видам", "synteny": "синтения", "introns": "интроны"}
    sig = "".join(f'<tr><td>{lab[k]}</td><td>{esc(names.get(v, "не решает") if v else "не решает")}</td></tr>'
                  for k, v in d.get("signals", {}).items())
    genes = list(names)
    per = d.get("per_species", {})
    rows = []
    for sp, v in sorted(per.items(), key=lambda kv: LINEAGE_INDEX.get(kv[0], 99)):
        cells = []
        for g in genes:
            c = (v.get("copies") or {}).get(g) or {}
            pres = v.get("present", {}).get(g)
            how = {"rbh": "взаимная лучшая находка", "synteny": "по соседним генам"}.get(c.get("present_by"), "")
            ex = (c.get("locus") or {}).get("exons")
            cells.append(f'<td>{"есть" if pres else "нет"}{f" ({how})" if pres and how else ""}'
                         f'{f", экзонов: {ex}" if pres and ex else ""}</td>')
        rows.append(f'<tr><td><i>{esc(sp_label(sp))}</i></td>{"".join(cells)}</tr>')
    pres_t = (f'<div class="scroll"><table><tr><th>Вид</th>{"".join(f"<th>{esc(names[g])}</th>" for g in genes)}</tr>'
              + "".join(rows) + '</table></div>')
    ex = d.get("exons", {})
    tree = d.get("tree") or {}
    tsvg = tree_svg(tree["newick"], highlight=[names.get(d.get("copy"), "~")]) if tree.get("newick") else ""
    tnote = (d.get("tree_signal") or {}).get("note", "")
    return (f'<h3>Признаки направления</h3><table><tr><th>Признак</th><th>Старше</th></tr>{sig}</table>'
            f'<p class="note">Кодирующих экзонов: ' + ", ".join(f"{esc(names[g])} — {ex.get(g)}" for g in genes)
            + f'. Родитель: <b>{esc(names.get(d.get("parent"), "не определён"))}</b>.</p>'
            f'<h3>Копии у видов</h3>{pres_t}'
            + (f'<h3>Дерево семейства ({esc(tree.get("model", ""))}; SH-aLRT/UFBoot)</h3>{tsvg}<p class="note">{esc(tnote)}</p>'
               if tsvg else ""))


# ---------- страница гена ----------
def gene_page(ev, full=True, back="index.html"):
    name = ev.get("name") or ev["gene"]
    body = (f'<div class="wrap"><p class="note"><a href="{esc(back)}">← все гены</a></p>'
            f'<div class="stack">{gene_sections(ev)}</div>'
            '<footer>GeneOrigin v2. Данные: файл выравниваний Peng &amp; Zhao 2024 (figshare 19989395), FlyBase r6.36, '
            'NCBI. Пороги — config.yaml, seed 42. Полные улики — evidence.json рядом с этим файлом.</footer></div>')
    return page(f"{name} — GeneOrigin", body, full)


def gene_sections(ev):
    v = ev["verdict"]
    name = ev.get("name") or ev["gene"]
    lik = ev.get("likelihood") or {}
    stab = ev.get("stability") or {}
    facts = [("Ветвь рождения", ev.get("origin_branch") or "—"),
             ("Уверенность", CONF_RU.get(ev.get("confidence"), "—")),
             ("Предковый участок", GRADE_RU.get(ev.get("outgroup_grade"), "—")),
             ("log10 LR de novo : древний (оценка при допущениях)", lik.get("log10_LR_denovo_vs_ancient", "—")),
             ("Устойчивость к порогам", stab.get("fraction", "—"))]
    fam = ev.get("family_origin")
    if fam:
        facts.append(("Происхождение семейства", f"предположительно de novo на {fam.get('origin_branch')}; "
                                                 f"этот ген — {ev.get('role_in_family', '?')}"))
    if ev.get("path_note"):
        facts.append(("Оговорка", ev["path_note"]))
    births = ev.get("birth_mutations") or []
    if births:
        facts.append(("Мутации рождения", ", ".join(f"{TYPE_RU.get(b['type'], b['type'])}, кодон {b['codon']}"
                                                    + ("" if b["polarized"] else " (кандидат)")
                                                    for b in births)))
    head = (f'<div class="head"><div><div class="id">{esc(ev["gene"])} · D. melanogaster</div>'
            f'<h1>{esc(name)}</h1></div>'
            f'<span class="chip v-{esc(v)}">{esc(VERDICT_RU.get(v, v))}'
            f'{" · " + esc(SUBTYPE_RU.get(ev.get("subtype"), ev.get("subtype") or "")) if ev.get("subtype") else ""}</span></div>'
            '<dl class="facts">' + "".join(f'<div><dt>{esc(k)}</dt><dd>{esc(val)}</dd></div>' for k, val in facts) + '</dl>')
    path = "".join(f'<li><span class="n">{esc(s["step"])}</span><div><div class="q">{esc(s["question"])}</div>'
                   f'<div class="a">{esc(s["answer"])}</div></div></li>' for s in ev.get("path", []))
    obs = [e for e in ev.get("evidence", []) if e["kind"] == "observation"]
    itp = [e for e in ev.get("evidence", []) if e["kind"] == "interpretation"]
    li = lambda e: f'<li>{esc(e["text"])} <span class="st">{esc(e["step"])}</span></li>'   # noqa: E731
    sections = [f'<section>{head}</section>',
                f'<section><h2>Путь по дереву решений</h2><ol class="path">{path}</ol></section>']
    if ev.get("species_status"):
        sections.append(f'<section><h2>Что лежит на месте гена у других видов</h2>{species_figure(ev)}</section>')
    if (ev.get("reconstruction") or {}).get("cds"):
        sections.append(f'<section><h2>Выравнивание вокруг ключевых кодонов</h2>{alignment_windows(ev)}</section>')
        sections.append(f'<section><h2>Реконструкция событий</h2>{events_table(ev)}</section>')
    if ev.get("duplication"):
        sections.append(f'<section><h2>Ветка дупликации</h2>{duplication_block(ev)}</section>')
    sections.append('<section><h2>Улики</h2><div class="cols">'
                    f'<div><h3>Наблюдения</h3><ul class="ev">{"".join(li(e) for e in obs)}</ul></div>'
                    f'<div><h3>Интерпретации</h3><ul class="ev">{"".join(li(e) for e in itp)}</ul></div></div></section>')
    return "".join(sections)


def combined_page(evs, title, intro=""):
    """Одна страница: оглавление + отчёты всех генов (переход по якорю #FBgn...)."""
    rows = "".join(
        f'<tr><td><a href="#{esc(e["gene"])}">{esc(e.get("name") or e["gene"])}</a><div class="id">{esc(e["gene"])}</div></td>'
        f'<td><span class="chip v-{esc(e["verdict"])}">{esc(VERDICT_RU.get(e["verdict"], e["verdict"]))}</span></td>'
        f'<td>{esc(SUBTYPE_RU.get(e.get("subtype"), e.get("subtype") or ""))}</td>'
        f'<td>{esc(e.get("origin_branch") or "—")}</td><td>{esc(CONF_RU.get(e.get("confidence"), "—"))}</td>'
        f'<td>{esc(e.get("role_note", ""))}</td></tr>' for e in evs)
    parts = "".join(f'<div id="{esc(e["gene"])}" class="stack" style="margin-top:36px;scroll-margin-top:12px">'
                    f'{gene_sections(e)}<p class="note"><a href="#top">↑ к списку</a></p></div>' for e in evs)
    body = (f'<div class="wrap" id="top"><h1>{esc(title)}</h1>{intro}'
            '<section style="margin-top:16px"><div class="scroll"><table><tr><th>Ген</th><th>Вердикт</th><th>Подтип</th>'
            f'<th>Ветвь</th><th>Уверенность</th><th>Зачем в наборе</th></tr>{rows}</table></div></section>{parts}'
            '<footer>GeneOrigin v2 · данные Peng &amp; Zhao 2024 (figshare 19989395), FlyBase r6.36, NCBI · '
            'строгий режим, seed 42.</footer></div>')
    return page(title, body, full=False)


def index_page(rows, full=True, link=lambda g: f"{g}/report.html", title="GeneOrigin: отчёты"):
    counts = {}
    for r in rows:
        counts[r["verdict"]] = counts.get(r["verdict"], 0) + 1
    btns = '<button type="button" aria-pressed="true" data-f="all">все · ' + str(len(rows)) + '</button>' + "".join(
        f'<button type="button" aria-pressed="false" data-f="{esc(k)}">{esc(VERDICT_RU.get(k, k))} · {n}</button>'
        for k, n in sorted(counts.items(), key=lambda kv: -kv[1]))
    trs = "".join(
        f'<tr data-v="{esc(r["verdict"])}"><td><a href="{esc(link(r["gene"]))}">{esc(r.get("name") or r["gene"])}</a>'
        f'<div class="id">{esc(r["gene"])}</div></td>'
        f'<td><span class="chip v-{esc(r["verdict"])}">{esc(VERDICT_RU.get(r["verdict"], r["verdict"]))}</span></td>'
        f'<td>{esc(SUBTYPE_RU.get(r.get("subtype"), r.get("subtype") or ""))}</td>'
        f'<td>{esc(r.get("origin_branch") or "—")}</td><td>{esc(CONF_RU.get(r.get("confidence"), "—"))}</td>'
        f'<td>{esc(r.get("birth_mutations") or "")}</td></tr>' for r in rows)
    js = ("<script>document.querySelectorAll('.filters button').forEach(b=>b.addEventListener('click',()=>{"
          "document.querySelectorAll('.filters button').forEach(x=>x.setAttribute('aria-pressed',x===b));"
          "const f=b.dataset.f;document.querySelectorAll('tbody tr').forEach(tr=>{tr.hidden=!(f==='all'||tr.dataset.v===f)})}))"
          "</script>")
    body = (f'<div class="wrap"><h1>{esc(title)}</h1>'
            '<p class="note">Вердикт каждого гена — результат последовательного дерева решений; '
            'в отчёте гена путь по шагам, рисунок участков, выравнивания и реконструкция событий.</p>'
            f'<div class="filters">{btns}</div><section><div class="scroll"><table><thead><tr><th>Ген</th><th>Вердикт</th>'
            '<th>Подтип</th><th>Ветвь</th><th>Уверенность</th><th>Мутации рождения</th></tr></thead>'
            f'<tbody>{trs}</tbody></table></div></section></div>{js}')
    return page(title, body, full)


def build_all(results_dir):
    rows = []
    for p in sorted(glob.glob(os.path.join(results_dir, "FBgn*", "evidence.json")) +
                    glob.glob(os.path.join(results_dir, "*", "evidence.json"))):
        ev = json.load(open(p))
        if any(r["gene"] == ev["gene"] for r in rows):
            continue
        with open(os.path.join(os.path.dirname(p), "report.html"), "w", encoding="utf-8") as f:
            f.write(gene_page(ev, back="../index.html"))
        rows.append({"gene": ev["gene"], "name": ev.get("name"), "verdict": ev["verdict"], "subtype": ev.get("subtype"),
                     "origin_branch": ev.get("origin_branch"), "confidence": ev.get("confidence"),
                     "birth_mutations": ", ".join(f"{b['type']}@{b['codon']}{'' if b['polarized'] else '?'}"
                                                  for b in ev.get("birth_mutations") or [])})
    with open(os.path.join(results_dir, "index.html"), "w", encoding="utf-8") as f:
        f.write(index_page(rows))
    return rows


if __name__ == "__main__":
    print(len(build_all(sys.argv[1])), "отчётов")
