"""species.py — виды, линии (lineages) и ветви рождения Br0..Br9 как у Peng & Zhao 2024.

Линии упорядочены от ближней к дальней относительно D. melanogaster (рис. 1a статьи).
Ветвь Br_i — участок «ствола» дерева, на котором ген появился, если ортолог есть у линии L_{i-1}
(самой дальней с геном), а у линии L_i его уже нет. Т.е. L_i — ближайшая внешняя группа.
Порядок и состав линий подобраны так, что правило воспроизводит ветви авторов
для 505 из 520 de novo генов (Genewise, P < 1e-6) — см. results/validation.
"""

LINEAGES = [
    ("L0", ["dsim", "dsec"]),
    ("L1", ["dyak", "dere"]),
    ("L2", ["dfic"]),
    ("L3", ["drho", "dele", "deug", "dbia", "dtak"]),
    ("L4", ["dkik"]),
    ("L5", ["dana"]),
    ("L6", ["dmir", "dpse", "dper"]),
    ("L7", ["dwil"]),
    ("L8", ["sleb"]),
    ("L9", ["blat", "bdor"]),      # Bactrocera — внешняя группа для всех Drosophilinae
]

SPECIES_NAMES = {
    "dmel": "D. melanogaster", "dsim": "D. simulans", "dsec": "D. sechellia",
    "dyak": "D. yakuba", "dere": "D. erecta", "dfic": "D. ficusphila",
    "drho": "D. rhopaloa", "dele": "D. elegans", "deug": "D. eugracilis",
    "dbia": "D. biarmipes", "dtak": "D. takahashii", "dkik": "D. kikkawai",
    "dana": "D. ananassae", "dmir": "D. miranda", "dpse": "D. pseudoobscura",
    "dper": "D. persimilis", "dwil": "D. willistoni", "sleb": "S. lebanonensis",
    "blat": "B. latifrons", "bdor": "B. dorsalis",
    # дальние членистоногие (только поиск гомологов по белкам)
    "mdom": "M. domestica", "agam": "A. gambiae", "aaeg": "A. aegypti",
    "bmor": "B. mori", "mpha": "M. pharaonis", "amel": "A. mellifera",
    "aflo": "A. florea", "dmag": "D. magna",
}

DISTANT_ARTHROPODS = ["mdom", "agam", "aaeg", "bmor", "mpha", "amel", "aflo", "dmag"]

# линия -> индекс; дальние членистоногие считаем линией 10 (дальше Bactrocera)
LINEAGE_INDEX = {sp: i for i, (_, sps) in enumerate(LINEAGES) for sp in sps}
LINEAGE_INDEX.update({sp: 10 for sp in DISTANT_ARTHROPODS})
LINEAGE_INDEX["dmel"] = -1

# Дерево для рисунков (внутри L3 политомия: порядок ветвлений в статье на рисунке не подписан).
SPECIES_NEWICK = ("(((((((((((dmel,(dsim,dsec)),(dyak,dere)),dfic),(drho,dele,deug,dbia,dtak)),"
                  "dkik),dana),(dmir,(dpse,dper))),dwil),sleb),(blat,bdor)),"
                  "(mdom,((agam,aaeg),(bmor,((mpha,(amel,aflo)),dmag)))));")


def branch_label(i):
    return f"Br{i}"


def lineage_of(species):
    return LINEAGE_INDEX.get(species)
