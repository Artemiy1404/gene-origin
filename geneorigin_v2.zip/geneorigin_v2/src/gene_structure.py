"""gene_structure.py — экзоны/интроны и геномный контекст гена D. melanogaster (FlyBase r6.36).

Источник — заголовки FASTA FlyBase (поле loc=). Никаких ручных данных:
 * число кодирующих экзонов  = число отрезков в loc= самой длинной CDS-изоформы;
 * интроны транскрипта       = промежутки между соседними экзонами (dmel-all-transcript);
 * «вложенный ген»           = весь ген лежит внутри интрона другого гена и не задевает его экзонов;
 * «перекрывание»            = CDS гена пересекает экзон другого гена (на любой цепи).
"""
import bisect
import collections
from io_utils import read_flybase_fasta


class FlyBaseIndex:
    def __init__(self, cds_fasta, transcript_fasta, gene_fasta, translation_fasta=None):
        self.cds = read_flybase_fasta(cds_fasta, keep_seq=True)
        self.tx = read_flybase_fasta(transcript_fasta, keep_seq=False)
        self.genes = {}
        for g in read_flybase_fasta(gene_fasta, keep_seq=False):
            self.genes[g["id"]] = g
        self.prot = {}
        if translation_fasta:
            for p in read_flybase_fasta(translation_fasta, keep_seq=True):
                for par in p["parent"]:
                    self.prot.setdefault(par, []).append(p)
        self.cds_by_gene = collections.defaultdict(list)
        for c in self.cds:
            for par in c["parent"]:
                self.cds_by_gene[par].append(c)
        # экзоны и интроны всех транскриптов, сгруппированные по хромосоме
        self.exons = collections.defaultdict(list)    # chrom -> [(start, end, gene, strand)]
        self.introns = collections.defaultdict(list)
        for t in self.tx:
            par = next(iter(t["parent"]), None)
            if par is None:
                continue
            segs = t["segments"]
            for s, e in segs:
                self.exons[t["chrom"]].append((s, e, par, t["strand"]))
            for (s1, e1), (s2, e2) in zip(segs, segs[1:]):
                if s2 - e1 > 1:
                    self.introns[t["chrom"]].append((e1 + 1, s2 - 1, par, t["strand"]))
        for d in (self.exons, self.introns):
            for chrom in d:
                d[chrom].sort()
        self._starts = {c: [x[0] for x in v] for c, v in self.exons.items()}

    # ---------- структура ----------
    def longest_cds(self, gene_id):
        cands = self.cds_by_gene.get(gene_id, [])
        return max(cands, key=lambda c: len(c["seq"])) if cands else None

    def longest_protein(self, gene_id):
        cands = self.prot.get(gene_id, [])
        return max(cands, key=lambda p: len(p["seq"])) if cands else None

    def coding_exon_count(self, gene_id):
        c = self.longest_cds(gene_id)
        return len(c["segments"]) if c else None

    def max_exon_count(self, gene_id):
        """максимум экзонов среди всех CDS-изоформ (интрон хотя бы в одной изоформе)."""
        cands = self.cds_by_gene.get(gene_id, [])
        return max((len(c["segments"]) for c in cands), default=None)

    def location(self, gene_id):
        g = self.genes.get(gene_id)
        if not g or not g["segments"]:
            return None
        return {"chrom": g["chrom"], "strand": g["strand"],
                "start": g["segments"][0][0], "end": g["segments"][-1][1], "name": g["name"]}

    # ---------- контекст ----------
    def _overlapping(self, store, chrom, start, end):
        out = []
        for s, e, gene, strand in store.get(chrom, []):
            if s > end:
                break
            if e >= start:
                out.append((s, e, gene, strand))
        return out

    def context(self, gene_id):
        """-> dict: nested_in (список генов-хозяев), overlaps_exon_of (список), strand-отношения."""
        loc = self.location(gene_id)
        if loc is None:
            return {"available": False}
        chrom, start, end = loc["chrom"], loc["start"], loc["end"]
        cds = self.longest_cds(gene_id)
        cds_segs = cds["segments"] if cds else [(start, end)]
        exon_hits = {}
        for s, e, other, strand in self._overlapping(self.exons, chrom, start, end):
            if other == gene_id:
                continue
            if any(s <= ce and e >= cs for cs, ce in cds_segs):
                exon_hits[other] = "same" if strand == loc["strand"] else "opposite"
        genes_touching_span = {o for s, e, o, st in self._overlapping(self.exons, chrom, start, end) if o != gene_id}
        nested = {}
        for s, e, host, strand in self._overlapping(self.introns, chrom, start, end):
            if host == gene_id or host in genes_touching_span:
                continue
            if s <= start and end <= e:
                nested[host] = "same" if strand == loc["strand"] else "opposite"
        names = {g: self.genes[g]["name"] for g in list(nested) + list(exon_hits) if g in self.genes}
        return {"available": True, "chrom": chrom, "start": start, "end": end, "strand": loc["strand"],
                "nested_in_intron_of": [{"gene": g, "name": names.get(g, ""), "strand": st}
                                        for g, st in sorted(nested.items())],
                "overlaps_exon_of": [{"gene": g, "name": names.get(g, ""), "strand": st}
                                     for g, st in sorted(exon_hits.items())]}

    def neighbors(self, gene_id, k=3, coding_only=True):
        """k ближайших генов слева и справа на той же хромосоме (для синтении)."""
        loc = self.location(gene_id)
        if loc is None:
            return []
        same = [g for g in self.genes.values()
                if g["chrom"] == loc["chrom"] and g["id"] != gene_id and g["segments"]
                and (not coding_only or g["id"] in self.cds_by_gene)]
        same.sort(key=lambda g: g["segments"][0][0])
        mids = [g["segments"][0][0] for g in same]
        i = bisect.bisect_left(mids, loc["start"])
        return [g["id"] for g in same[max(0, i - k):i] + same[i:i + k]]
