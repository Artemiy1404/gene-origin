"""regions.py — что лежит у каждого вида на месте гена и что мешает этому участку быть геном.

Для каждого вида из файла выравниваний:
  1. Размеченный ортолог (score_1E10 в заголовке)                -> gene_annotated
  2. Неразмеченный участок: P-value счёта Genewise против случайных симуляций (как у авторов).
       P < p_coding                                                -> gene_unannotated
         + проверка целостности (ATG, нет стопов, нет сдвига)        -> intact / defective
  3. Иначе участок не похож на ген (noncoding). Насколько надёжно это «тот же» участок:
       grade = dna          — ДНК выравнивается с CDS dmel (blastn, покрытие >= min_dna_coverage)
       grade = trace        — есть слабый след сходства (короткий blastn или P Genewise/Spaln < p_trace)
       grade = synteny_only — место найдено только по синтении Cactus, сходства не видно
                              (такой участок сам по себе не доказывает de novo)
  4. Вида нет в файле                                              -> no_region

Поломки ищем двумя независимыми способами:
  a) по предсказанию Genewise/Spaln (секции II/III): старт-кодон, стопы в рамке, флаг сдвига;
  b) по прямому выравниванию ДНК (blastn): какой кодон стоит у вида на месте ATG и стоп-кодона
     гена dmel, где внутри появляются стопы, где инделы не кратны 3 (сдвиг рамки).
"""
import os
import subprocess
import tempfile
from Bio.Seq import Seq

from coding_potential import score_pvalue
from species import LINEAGE_INDEX

STOPS = {"TAA", "TAG", "TGA"}


def translate(nt):
    nt = nt[: len(nt) // 3 * 3]
    return str(Seq(nt).translate()) if nt else ""


def predicted_defects(seq, shift_flag):
    """Поломки в предсказании Genewise/Spaln (последовательность CDS вида)."""
    prot = translate(seq)
    inner = prot[:-1] if prot.endswith("*") else prot
    return {"starts_with_ATG": seq[:3] == "ATG",
            "internal_stops": inner.count("*"),
            "stop_positions_aa": [i + 1 for i, a in enumerate(inner) if a == "*"],
            "frameshift": bool(shift_flag) or (len(seq) % 3 != 0),
            "pred_len_aa": len(inner)}


# ---------------- blastn: прямое сравнение ДНК ----------------
BLASTN_FIELDS = "sseqid qstart qend sstart send evalue bitscore pident length qseq sseq"


def blastn_regions(query_nt, regions, blast_bin="", evalue=1e-3, word_size=7):
    """query_nt — CDS dmel; regions — {name: seq}. -> {name: [hsp,...]}."""
    out = {k: [] for k in regions}
    if not regions:
        return out
    with tempfile.TemporaryDirectory() as tmp:
        q = os.path.join(tmp, "q.fa")
        s = os.path.join(tmp, "s.fa")
        with open(q, "w") as f:
            f.write(">q\n" + query_nt + "\n")
        with open(s, "w") as f:
            for k, v in regions.items():
                f.write(f">{k}\n{v}\n")
        cmd = [os.path.join(blast_bin, "blastn"), "-query", q, "-subject", s, "-task", "blastn",
               "-word_size", str(word_size), "-evalue", str(evalue), "-dust", "no",
               "-outfmt", "6 " + BLASTN_FIELDS]
        res = subprocess.run(cmd, capture_output=True, text=True, check=True).stdout
    for line in res.splitlines():
        v = dict(zip(BLASTN_FIELDS.split(), line.split("\t")))
        for k in ("qstart", "qend", "sstart", "send", "length"):
            v[k] = int(v[k])
        for k in ("evalue", "bitscore", "pident"):
            v[k] = float(v[k])
        out[v["sseqid"]].append(v)
    return out


def tblastn_regions(protein, regions, blast_bin="", evalue=10):
    """Белок гена против каждого участка (6 рамок). -> {имя: {'evalue', 'qcov'}} (лучшая HSP + покрытие)."""
    out = {}
    if not regions:
        return out
    with tempfile.TemporaryDirectory() as tmp:
        q, s = os.path.join(tmp, "q.fa"), os.path.join(tmp, "s.fa")
        open(q, "w").write(">q\n" + protein + "\n")
        with open(s, "w") as f:
            for k, v in regions.items():
                f.write(f">{k}\n{v}\n")
        res = subprocess.run([os.path.join(blast_bin, "tblastn"), "-query", q, "-subject", s,
                              "-evalue", str(evalue), "-seg", "no",
                              "-outfmt", "6 sseqid evalue qstart qend qlen"],
                             capture_output=True, text=True, check=True).stdout
    cover = {}
    for line in res.splitlines():
        k, e, a, b, ql = line.split("\t")
        d = out.setdefault(k, {"evalue": float(e), "qcov": 0.0})
        d["evalue"] = min(d["evalue"], float(e))
        cover.setdefault(k, set()).update(range(int(a), int(b) + 1))
        d["qcov"] = round(100 * len(cover[k]) / int(ql), 1)
    return out


def codon_walk(hsps, cds_len):
    """По выравниваниям blastn смотрим кодоны вида на позициях кодонов гена dmel."""
    cover = set()
    stops, shifts = [], []
    start_codon = stop_codon = None
    last_codon = cds_len // 3              # номер кодона стоп-кодона dmel (1-based)
    for h in sorted(hsps, key=lambda x: x["evalue"]):
        q, qs, ss = h["qstart"], h["qseq"], h["sseq"]
        codon_q, codon_s = {}, {}
        gap_run_q = gap_run_s = 0
        for a, b in zip(qs, ss):
            if a == "-":
                gap_run_q += 1
                if b != "-":
                    continue
            else:
                if gap_run_q and gap_run_q % 3:
                    shifts.append({"codon": (q - 1) // 3 + 1, "type": f"вставка {gap_run_q} н."})
                gap_run_q = 0
            if b == "-":
                gap_run_s += 1
            else:
                if gap_run_s and gap_run_s % 3:
                    shifts.append({"codon": (q - 1) // 3 + 1, "type": f"делеция {gap_run_s} н."})
                gap_run_s = 0
            if a != "-":
                cover.add(q)
                ci = (q - 1) // 3 + 1
                codon_q.setdefault(ci, []).append(a)
                codon_s.setdefault(ci, []).append(b)
                q += 1
        for ci, bases in codon_s.items():
            if len(bases) == 3 and "-" not in bases:
                cod = "".join(bases).upper()
                if ci == 1 and start_codon is None:
                    start_codon = cod
                if ci == last_codon and stop_codon is None:
                    stop_codon = cod
                if ci < last_codon and cod in STOPS:
                    stops.append(ci)
    shifts = {(s["codon"], s["type"]): s for s in shifts}.values()
    return {"dna_coverage": round(len(cover) / cds_len, 3) if cds_len else 0.0,
            "codon_at_ATG": start_codon, "codon_at_stop": stop_codon,
            "inframe_stops_codons": sorted(set(stops)),
            "frameshifts": sorted(shifts, key=lambda s: s["codon"])}


def classify_species(gene_records, cfg, blast_bin=""):
    """gene_records — {'raw': [...], 'spaln': [...], 'genewise': [...]} для одного гена."""
    c = cfg["orf"]
    dmel = next(r for r in gene_records["raw"] if r["species"] == "dmel" and r["annotated"])
    cds = dmel["seq"]
    n_aa = len(cds) // 3 - 1
    by_sp = {}
    for r in gene_records["raw"]:
        if r["species"] == "dmel":
            continue
        by_sp.setdefault(r["species"], []).append(r)

    unann = {}
    for r in gene_records["raw"]:
        if r["species"] != "dmel" and not r["annotated"]:
            unann[r["species"] + "|" + r["id"]] = r["seq"]
    hsps = blastn_regions(cds, unann, blast_bin, c["blastn_evalue"], c["blastn_word"])

    pred = {}
    for method in ("genewise", "spaln"):
        for r in gene_records[method]:
            if r["species"] == "dmel" or r["annotated"]:
                continue
            s, z, p = score_pvalue(r["score"], n_aa, method)
            pred.setdefault(r["species"] + "|" + r["id"], {})[method] = {
                "score": r["score"], "norm_score": round(s, 4), "z": round(z, 2), "p": p,
                **predicted_defects(r["seq"], r["shift"])}

    # Свои данные без готовых Genewise/Spaln (вход из FASTA): tblastn белка гена по участку
    # + проверка целостности рамки по выравниванию ДНК (reconstruction.compare).
    missing = {k: v for k, v in unann.items() if not pred.get(k)}
    if missing:
        prot = translate(cds).rstrip("*")
        tb = tblastn_regions(prot, missing, blast_bin)
        from reconstruction import compare
        for k, seq in missing.items():
            h = tb.get(k)
            cmp = compare(cds, seq, n_null=0)
            pred.setdefault(k, {})["tblastn"] = {
                "p": h["evalue"] if h else 1.0, "qcov": h["qcov"] if h else 0.0,
                "starts_with_ATG": cmp["start_triplet"] == "ATG",
                "internal_stops": len(cmp["stops_in_frame"]),
                "frameshift": any(not f["compensated"] for f in cmp["frameshifts"]),
                "orf_fraction": cmp["orf_fraction"]}

    result = {}
    for sp, recs in by_sp.items():
        entries = []
        for r in recs:
            if r["annotated"]:
                entries.append({"record": r["id"], "annotated": True})
                continue
            key = sp + "|" + r["id"]
            pm = pred.get(key, {})
            entries.append({"record": r["id"], "annotated": False, "predicted_all": pm,
                            "dna": codon_walk(hsps.get(key, []), len(cds))})
        result[sp] = {"lineage": LINEAGE_INDEX.get(sp), "entries": entries}
    out = {"protein_len": n_aa, "cds_len": len(cds), "species": result}
    return restatus(out, cfg)


def restatus(regions, cfg):
    """Присвоить статусы по порогам из cfg (без повторного BLAST) — нужно для проверки устойчивости."""
    c = cfg["orf"]
    prim = c["primary_method"]
    sec = "spaln" if prim == "genewise" else "genewise"
    rank = {"gene_annotated": 0, "gene_unannotated_intact": 1, "gene_unannotated_defective": 2, "noncoding": 3}
    grank = {"dna": 0, "trace": 1, "synteny_only": 2, None: 0}
    for sp, v in regions["species"].items():
        for e in v["entries"]:
            if e["annotated"]:
                e["status"], e["grade"] = "gene_annotated", None
                continue
            primary = e["predicted_all"].get(prim, {})
            secondary = e["predicted_all"].get(sec, {})
            p_thr = c["p_coding"]
            if not primary and "tblastn" in e["predicted_all"]:
                # вход из FASTA: вместо Genewise — tblastn (E-value) и требование покрытия белка
                primary = dict(e["predicted_all"]["tblastn"])
                if primary.get("qcov", 0) < c.get("tblastn_min_qcov", 50):
                    primary["p"] = 1.0
                p_thr = c.get("tblastn_evalue", 1e-5)
            p = primary.get("p", 1.0)
            p_min = min(p, secondary.get("p", 1.0))
            walk = e["dna"]
            if walk["dna_coverage"] >= c["min_dna_coverage"]:
                grade = "dna"            # ДНК участка выравнивается с CDS dmel (blastn)
            elif walk["dna_coverage"] > 0 or p_min < c["p_trace"]:
                grade = "trace"          # слабый след сходства (короткий blastn или Genewise/Spaln P < p_trace)
            else:
                grade = "synteny_only"   # место найдено только по синтении (Cactus), сходства не видно
            if p < p_thr:
                intact = (primary.get("starts_with_ATG") and primary.get("internal_stops") == 0
                          and not primary.get("frameshift"))
                status = "gene_unannotated_intact" if intact else "gene_unannotated_defective"
            else:
                status = "noncoding"
            e.update(status=status, grade=grade, p_coding=p, z=primary.get("z"),
                     norm_score=primary.get("norm_score"),
                     predicted={"primary": primary, "secondary": secondary})
        # лучший участок вида: ген > некодирующий с выравниванием > только синтения
        best = sorted(v["entries"], key=lambda e: (rank[e["status"]], grank[e.get("grade")],
                                                    e.get("p_coding", 0)))[0]
        v.update(status=best["status"], best=best, n_records=len(v["entries"]))
    return regions


def is_gene(status):
    return status.startswith("gene_")
