"""decision_tree.py — последовательный вердикт GeneOrigin v2 (вместо суммы баллов).

Каждый шаг отвечает на один вопрос, и ответ выбирает следующий шаг:

 Ш1  Есть ли паралог в геноме D. melanogaster? (blastp, E < 1e-5, покрытие >= 50 %)
      да  -> Д1–Д4: кто родитель (распространение, синтения, интроны со стыками экзонов, дерево)
             ген = копия     -> ДУПЛИКАЦИЯ (ретрокопия / предполагаемая / механизм не уточнён)
             ген = родитель  -> ДРЕВНИЙ (родитель дупликации)
             не решено       -> ДУПЛИКАЦИЯ, направление не определено
      нет -> Ш2
 Ш2  Есть ли синтенные участки у других видов? (файл выравниваний статьи)
      нет -> по blastp: гомологи у дальних членистоногих -> ДРЕВНИЙ, иначе НЕДОСТАТОЧНО ДАННЫХ
 Ш3  У каких линий на этом месте ген? -> самая дальняя линия с геном L_k; ветвь рождения Br_{k+1}
      ген есть и у самой дальней выровненной линии -> ДРЕВНИЙ (старше всех выровненных видов)
 Ш4  Что лежит у внешних линий и что мешает ему быть геном (нет ATG / стопы / сдвиг рамки)?
      Предковое состояние: рамка сломана / нет кодирующего сходства / неизвестно (только синтения)
 Ш5  Есть ли гомологи у видов дальше ветви рождения? (blastp по 27 протеомам
      + необязательный внешний поиск jackhmmer/tblastn) -> да: ДРЕВНИЙ (старше ветви; положение не проверено)
      нет, а предок «только по синтении» -> НЕДОСТАТОЧНО ДАННЫХ (строгий режим)
 Ш6  Поломки у видов ВНУТРИ группы с геном -> потеря после рождения (интерпретация)
 Ш7  Ранжирующая оценка: de novo на Br_i против «древний + независимые потери во всех внешних линиях»
      (не фильтр: при q = 0,039 одна линия уже даёт 1,41; порог min_log10_lr по умолчанию выключен)
 Ш8  Где лежит ген: межгенный / в интроне другого гена / перекрывает экзон -> подтип вердикта
"""
import math

from species import LINEAGES, SPECIES_NAMES, branch_label
from regions import is_gene
import homology

GRADE_RANK = {"dna": 0, "trace": 1, "synteny_only": 2}
GRADE_RU = {"dna": "ДНК выравнивается", "trace": "слабый след сходства",
            "synteny_only": "только место по синтении"}


class Trace:
    """Путь по дереву + улики (наблюдение отдельно от интерпретации)."""
    def __init__(self):
        self.steps, self.evidence = [], []

    def step(self, code, question, answer):
        self.steps.append({"step": code, "question": question, "answer": answer})

    def obs(self, step, text, **data):
        self.evidence.append({"kind": "observation", "step": step, "text": text, **data})

    def interp(self, step, text, **data):
        self.evidence.append({"kind": "interpretation", "step": step, "text": text, **data})


def sp_name(code):
    return SPECIES_NAMES.get(code, code)


def describe_defects(entry):
    """Что мешает участку быть геном — человеческим языком + машинно."""
    out = []
    pr = (entry.get("predicted") or {}).get("primary") or {}
    dna = entry.get("dna") or {}
    if dna.get("codon_at_ATG") and dna["codon_at_ATG"] != "ATG":
        out.append(("no_ATG", f"на месте ATG стоит {dna['codon_at_ATG']}"))
    elif pr and not pr.get("starts_with_ATG", True):
        out.append(("no_ATG", "предсказанная рамка начинается не с ATG"))
    stops = dna.get("inframe_stops_codons") or []
    if stops:
        out.append(("stop", f"стоп-кодоны в рамке гена на кодонах {', '.join(map(str, stops[:5]))}"))
    elif pr.get("internal_stops"):
        out.append(("stop", f"{pr['internal_stops']} стоп-кодон(а) внутри предсказанной рамки"))
    shifts = dna.get("frameshifts") or []
    if shifts:
        out.append(("frameshift", "сдвиг рамки: " + "; ".join(f"кодон {s['codon']} ({s['type']})" for s in shifts[:3])))
    elif pr.get("frameshift"):
        out.append(("frameshift", "Genewise/Spaln вставили сдвиг рамки"))
    if dna.get("codon_at_stop") and dna["codon_at_stop"] not in ("TAA", "TAG", "TGA"):
        out.append(("stop_lost", f"на месте стоп-кодона гена стоит {dna['codon_at_stop']}"))
    return out


def lineage_table(regions):
    """-> {lineage_idx: {"species": {...}, "has_gene": bool, "best_grade": ...}}"""
    table = {}
    for sp, v in regions["species"].items():
        li = v["lineage"]
        if li is None:
            continue
        t = table.setdefault(li, {"species": {}, "has_gene": False, "best_grade": None})
        t["species"][sp] = v
        if is_gene(v["status"]):
            t["has_gene"] = True
        else:
            g = v["best"].get("grade")
            if t["best_grade"] is None or GRADE_RANK[g] < GRADE_RANK[t["best_grade"]]:
                t["best_grade"] = g
    return table


def decide(gene_id, inp, cfg):
    """inp: dict с ключами
         name, hits (blastp all28 для гена), regions (regions.classify_species или None),
         context (gene_structure.context), dup (функция gene,paralog -> resolve_parent),
         external_homology (список внешних находок или None), loss_rate (q).
    """
    tr = Trace()
    dcfg = cfg["decide"]
    res = {"gene": gene_id, "name": inp.get("name", ""), "verdict": None, "subtype": None,
           "origin_branch": None, "confidence": None}

    # ---------- Ш1 паралоги ----------
    hits = inp.get("hits") or []
    pars = homology.paralogs(hits, gene_id, cfg)
    if pars:
        b = pars[0]
        tr.step("1", "Есть ли паралог в геноме D. melanogaster?",
                f"да: {b['subject_gene']} ({b['pident']:.1f} % идентичности, E = {b['evalue']:.1e}, покрытие {b['qcovs']:.0f} %)")
        for p in pars[:3]:
            tr.obs("homology", f"blastp: паралог {p['subject_gene']}, E = {p['evalue']:.1e}, "
                               f"идентичность {p['pident']:.1f} %, покрытие {p['qcovs']:.0f} %",
                   evalue=p["evalue"], pident=p["pident"], qcov=p["qcovs"], subject=p["subject_gene"])
        dup = inp["dup"](gene_id, b["subject_gene"]) if inp.get("dup") else None
        res["duplication"] = _strip_dup(dup)
        res = _duplication_branch(gene_id, b["subject_gene"], dup, tr, res, cfg)
        # Д5: копия может быть копией МОЛОДОГО гена. Проверяем, новое ли всё семейство:
        # проходим Ш2–Ш8 для самого гена (паралоги в dmel на этих шагах не мешают).
        if not inp.get("regions") or res["subtype"] == "retrocopy" and res["confidence"] == "high":
            return res
        fam_inp = dict(inp, hits=[h for h in hits if h["species"] != "dmel"], dup=None)
        fam = decide(gene_id, fam_inp, cfg)
        res["family_check"] = {"verdict": fam["verdict"], "subtype": fam["subtype"],
                               "origin_branch": fam.get("origin_branch")}
        if fam["verdict"] == "de_novo":
            # Два разных вопроса — два ответа: как возник ЭТОТ ген и как возникло его семейство.
            if res["subtype"] == "parent_of_duplicate":
                role = "родитель"
            elif res["subtype"] == "direction_unresolved":
                role = "одна из копий (направление не определено)"
            else:
                role = "копия"
            note = ("семейство оценено по месту этого гена (Ш2–Ш8 без паралогов dmel); "
                    "место второй копии отдельно не анализировалось")
            family = {"verdict": "de_novo", "origin_branch": fam["origin_branch"], "confidence": fam["confidence"],
                      "subtype": fam["subtype"], "note": note}
            tr.step("Д5", "Новое ли всё семейство (Ш2–Ш8 без учёта паралогов dmel)?",
                    f"предположительно да: семейство de novo на ветви {fam['origin_branch']}; ген — {role}")
            if role == "родитель":
                # исходная копия семейства и есть ген, возникший de novo; его копия появилась позже
                tr.interp("decide", "ген — исходная копия семейства: он возник de novo, а копия появилась позже")
                out = dict(fam)
                out["path"] = tr.steps + fam["path"][1:]
                out["evidence"] = tr.evidence + [e for e in fam["evidence"]
                                                 if e["step"] != "homology" or "паралог" not in e["text"]]
                out["subtype"] = "parent_of_later_duplicate"
                out["duplication"] = res.get("duplication")
                out["role_in_family"] = role
                out["family_origin"] = family
                return out
            tr.interp("decide", f"этот ген возник дупликацией ({role}); семейство, к которому он относится, "
                                f"предположительно возникло de novo на ветви {fam['origin_branch']} до дупликации")
            res["role_in_family"] = role
            res["family_origin"] = family
            res["path"] = tr.steps
            res["evidence"] = tr.evidence
            return res
        tr.step("Д5", "Новое ли всё семейство (Ш2–Ш8 без учёта паралогов dmel)?",
                f"нет: {fam['verdict']} ({fam['subtype']})")
        res["path"] = tr.steps
        res["evidence"] = tr.evidence
        return res
    tr.step("1", "Есть ли паралог в геноме D. melanogaster?", "нет (blastp, E < "
            f"{cfg['homology']['paralog_evalue']:.0e}, покрытие >= {cfg['homology']['paralog_min_qcov']} %)")
    tr.obs("homology", "паралогов в протеоме D. melanogaster r6.36 не найдено")

    # ---------- Ш2 есть ли синтенные данные ----------
    regions = inp.get("regions")
    if not regions:
        far = [h for h in hits if h["species"] in ("mdom", "agam", "aaeg", "bmor", "mpha", "amel", "aflo", "dmag", "bdor", "blat")
               and h["evalue"] < cfg["homology"]["outside_evalue"]]
        tr.step("2", "Есть ли участки с того же места у других видов?", "нет в файле выравниваний")
        if far:
            best = min(far, key=lambda h: h["evalue"])
            tr.obs("homology", f"blastp: гомолог у {sp_name(best['species'])} (E = {best['evalue']:.1e})")
            return _finish(res, tr, "ancient", "homolog_in_distant_species", None,
                           "high" if best["species"] not in ("bdor", "blat") else "medium")
        return _finish(res, tr, "insufficient_data", "no_syntenic_data", None, "none")
    tr.step("2", "Есть ли участки с того же места у других видов?",
            f"да: {len(regions['species'])} видов в выравнивании Cactus")

    # ---------- Ш3 линии с геном ----------
    res["protein_len"] = regions.get("protein_len")
    lt = lineage_table(regions)
    present = sorted(lt)
    with_gene = [li for li in present if lt[li]["has_gene"]]
    l0 = max(with_gene) if with_gene else -1
    for li in present:
        for sp, v in sorted(lt[li]["species"].items()):
            st = v["status"]
            b = v["best"]
            if st == "gene_annotated":
                tr.obs("orf", f"{sp_name(sp)}: размеченный ортолог")
            elif st.startswith("gene_unannotated"):
                meth = "tblastn E" if "tblastn" in (b.get("predicted_all") or {}) and "genewise" not in (b.get("predicted_all") or {}) else "Genewise P"
                tr.obs("orf", f"{sp_name(sp)}: неразмеченный участок похож на ген ({meth} = {b['p_coding']:.1e}"
                              f"{', рамка целая' if st.endswith('intact') else ', рамка с поломками'})",
                       species=sp, p=b["p_coding"])
            else:
                tr.obs("orf", f"{sp_name(sp)}: значимого сходства с кодирующей рамкой гена нет "
                              f"(P случайной ДНК = {b['p_coding']:.2f}; {GRADE_RU[b['grade']]})",
                       species=sp, p=b["p_coding"], grade=b["grade"])
    if l0 == max(present):
        tr.step("3", "У каких линий на этом месте ген?",
                f"у всех вплоть до самой дальней выровненной ({LINEAGES[l0][0]}: {', '.join(LINEAGES[l0][1])})")
        tr.interp("phylo", "ген старше всех выровненных видов; рождение de novo внутри группы не подтверждается")
        return _finish(res, tr, "ancient", "ortholog_in_farthest_lineage", None, "high")
    outgroups = [li for li in present if li > l0]
    origin = outgroups[0]
    res["origin_branch"] = branch_label(origin)
    res["l0"] = l0
    tr.step("3", "У каких линий на этом месте ген?",
            f"самая дальняя линия с геном: {LINEAGES[l0][0] if l0 >= 0 else 'только dmel'}; "
            f"ближайшая линия без гена: {LINEAGES[origin][0]} -> ветвь рождения {branch_label(origin)}")
    tr.interp("phylo", f"если ген de novo, он появился на ветви {branch_label(origin)}")

    # ---------- Ш4 внешние линии: что мешает быть геном ----------
    best_grade = min((lt[li]["best_grade"] for li in outgroups), key=lambda g: GRADE_RANK[g])
    nearest = lt[origin]
    defects_near = {}
    for sp, v in nearest["species"].items():
        d = describe_defects(v["best"])
        defects_near[sp] = [t for _, t in d]
        for code, text in d:
            tr.obs("orf", f"{sp_name(sp)} (ближайшая внешняя линия): {text}", species=sp, defect=code)
    res["outgroup_grade"] = best_grade
    res["nearest_outgroup_defects"] = defects_near
    res["outgroup_p_random"] = {sp: v["best"]["p_coding"] for li in outgroups for sp, v in lt[li]["species"].items()}
    tr.step("4", "Что лежит у внешних линий на месте гена?",
            f"{len(outgroups)} линий без гена; лучший уровень доказательности: {GRADE_RU[best_grade]}")
    # что известно о предковом состоянии (отдельно от того, «ген» ли участок)
    if best_grade == "synteny_only":
        res["ancestral_state"] = "unknown"
    elif any(defects_near.values()):
        res["ancestral_state"] = "frame_broken"
    else:
        res["ancestral_state"] = "no_coding_similarity"
    if best_grade == "synteny_only":
        tr.interp("decide", "у внешних видов место найдено, но последовательность не выравнивается: "
                            "состояние предкового участка определить нельзя (это нехватка данных, "
                            "а не доказательство некодирующего предка)")
    # строгий выход «недостаточно данных» — ПОСЛЕ проверки гомологов (Ш5): найденный дальний гомолог
    # сам по себе ответ, и его нельзя терять из-за невыравниваемого участка

    # ---------- Ш5 гомологи вне синтенного места ----------
    # scope = all_outgroups: гомолог у любого вида дальше линии с геном (наше правило, строже);
    # scope = beyond_aligned: только у видов дальше самой дальней выровненной линии (правило авторов)
    # Линии между l0 и ближайшей внешней, у которых участка в выравнивании НЕТ, синтенией не проверены:
    # находка blastp там — скорее ортолог на невыровненном месте, а не «гомолог вне синтении».
    # Поэтому считаем только линии начиная с ближайшей внешней (у неё участок есть и он не ген).
    scope_from = origin - 1 if cfg["homology"].get("outside_scope", "all_outgroups") == "all_outgroups" else max(present)
    skipped = sorted({h["species"] for h in hits if h["species"] != "dmel"
                      and l0 < homology.LINEAGE_INDEX.get(h["species"], -1) < origin
                      and h["evalue"] < cfg["homology"]["outside_evalue"]})
    if skipped:
        tr.obs("homology", "blastp находит белок у видов без участка в выравнивании ("
               + ", ".join(sp_name(x) for x in skipped) + "): вероятно, ортологи на невыровненном месте")
    out_h = homology.outside_homologs(hits, scope_from, cfg)
    beyond = [h for h in hits if h["species"] != "dmel" and homology.LINEAGE_INDEX.get(h["species"], -1) > l0]
    res["best_outside_E"] = min((h["evalue"] for h in beyond), default=1.0)
    ext = inp.get("external_homology") or []
    if out_h or ext:
        txt = []
        for h in out_h[:3]:
            txt.append(f"{sp_name(h['species'])} E = {h['evalue']:.1e}")
            has_region = h["species"] in regions["species"]
            tr.obs("homology", f"blastp: белок-гомолог у {sp_name(h['species'])} "
                               f"(E = {h['evalue']:.1e}, покрытие {h['qcovs']:.0f} %); положение относительно "
                               f"синтенного участка не проверено"
                               + ("; сам синтенный участок этого вида не похож на ген" if has_region else ""),
                   species=h["species"], evalue=h["evalue"])
        for e in ext:
            txt.append(f"{e['source']}")
            tr.obs("homology", f"внешний поиск ({e['source']}): {e.get('detail', '')}")
        tr.step("5", "Есть ли гомологи у видов дальше ветви рождения?", "да: " + "; ".join(txt))
        tr.interp("decide", "у видов вне группы есть родственный белок: ген, вероятно, старше предложенной ветви "
                            "рождения, и de novo на ней не подтверждается. Сильно ли он изменился на месте или "
                            "переместился, без проверки координат находки сказать нельзя")
        res["outside_homologs"] = [{"species": h["species"], "evalue": h["evalue"], "qcov": h["qcovs"]} for h in out_h]
        return _finish(res, tr, "ancient", "homolog_beyond_origin", None, "medium")
    tr.step("5", "Есть ли гомологи у видов дальше ветви рождения?",
            "нет (blastp по 27 протеомам" + (", внешний поиск тоже пуст)" if inp.get("external_checked") else ")"))
    if best_grade == "synteny_only" and dcfg.get("strict_alignable_outgroup", True):
        res["path_note"] = "de novo не исключён, но предковый участок не выравнивается"
        return _finish(res, tr, "insufficient_data", "outgroup_unalignable", None, "low")

    # ---------- Ш6 потери внутри группы ----------
    losses = []
    for li in present:
        if li > l0:
            continue
        for sp, v in lt[li]["species"].items():
            if not is_gene(v["status"]):
                d = [t for _, t in describe_defects(v["best"])]
                losses.append({"species": sp, "lineage": li, "defects": d})
                tr.obs("orf", f"{sp_name(sp)} внутри группы с геном: гена нет"
                              + (f" ({'; '.join(d)})" if d else ""), species=sp)
    if losses:
        tr.interp("phylo", "при гипотезе de novo на этой ветви виды без гена внутри группы объясняются "
                           "потерей после рождения: " + ", ".join(sp_name(x["species"]) for x in losses))
    tr.step("6", "Есть ли поломки у видов внутри группы с геном?",
            "да: " + ", ".join(sp_name(x["species"]) for x in losses) if losses else "нет")
    res["losses"] = losses

    # ---------- Ш7 правдоподобие ----------
    q = inp.get("loss_rate") or 0.1
    m_out = len(outgroups)
    log10_lr = m_out * math.log10(1 / q)
    res["likelihood"] = {"loss_rate_q": round(q, 4), "outgroup_lineages_without_gene": m_out,
                         "log10_LR_denovo_vs_ancient": round(log10_lr, 2)}
    tr.obs("decide", f"внешних линий без гена на этом месте: {m_out}")
    tr.interp("decide", f"упрощённая оценка: гипотеза «древний ген» потребовала бы {m_out} независимых потерь во "
                        f"внешних линиях; при доле потерь q = {q:.3f} и независимости потерь "
                        f"log10 LR(de novo : древний) = {log10_lr:.2f}. Это ранжирующая оценка при допущениях, "
                        f"а не вероятность происхождения")
    tr.step("7", "Ранжирующая оценка: de novo против «древний + независимые потери»",
            f"log10 LR = {log10_lr:.2f} (при допущениях; не фильтр и не вероятность)")
    if dcfg.get("min_log10_lr") is not None and log10_lr < dcfg["min_log10_lr"]:
        return _finish(res, tr, "insufficient_data", "weak_likelihood", None, "low")

    # ---------- Ш8 положение гена ----------
    ctx = inp.get("context") or {}
    sub = "intergenic"
    if not ctx.get("available"):
        sub = "context_unknown"
        tr.obs("context", "положение гена в геноме D. melanogaster неизвестно (нет разметки)")
    elif ctx.get("overlaps_exon_of"):
        hosts = ", ".join(f"{h['name'] or h['gene']} ({'та же' if h['strand'] == 'same' else 'противоположная'} цепь)"
                          for h in ctx["overlaps_exon_of"][:2])
        sub = "overlapping_exon"
        tr.obs("context", f"CDS перекрывает экзон другого гена: {hosts}")
        tr.interp("decide", "возможен иной механизм: перекрывающийся ген / наложение рамки на чужой экзон")
    elif ctx.get("nested_in_intron_of"):
        hosts = ", ".join(f"{h['name'] or h['gene']} ({'та же' if h['strand'] == 'same' else 'противоположная'} цепь)"
                          for h in ctx["nested_in_intron_of"][:2])
        sub = "nested_in_intron"
        tr.obs("context", f"ген целиком лежит в интроне гена {hosts}")
    tr.step("8", "Где лежит ген?", {"intergenic": "между генами", "nested_in_intron": "в интроне другого гена",
                                     "overlapping_exon": "перекрывает экзон другого гена",
                                     "context_unknown": "неизвестно (нет разметки)"}[sub])
    conf = "high" if best_grade == "dna" and log10_lr >= 2 else ("medium" if best_grade in ("dna", "trace") else "low")
    for sp, d in defects_near.items():
        if d:
            tr.interp("phylo", f"если ген de novo, участок до его рождения мог выглядеть так ({sp_name(sp)}): {'; '.join(d)}")
    if best_grade == "synteny_only":
        res["path_note"] = "происхождение de novo возможно; состояние предполагаемого предкового участка определить не удалось"
        tr.interp("decide", res["path_note"])
    return _finish(res, tr, "de_novo", sub, res["origin_branch"], conf)


def _duplication_branch(gene_id, paralog, dup, tr, res, cfg):
    if not dup:
        tr.step("Д", "Кто из двух копий родитель?", "не проверялось (нет данных по видам)")
        return _finish(res, tr, "duplication", "direction_unresolved", None, "low")
    names = dup["names"]
    s = dup["signals"]
    lab = {"distribution": "распространение по видам", "synteny": "синтения", "introns": "интроны"}
    for k, v in s.items():
        tr.obs("phylo", f"признак «{lab[k]}»: " + (f"старше {names[v]}" if v else "не решает"))
    tr.obs("phylo", f"экзонов: {names[gene_id]} — {dup['exons'][gene_id]}, {names[paralog]} — {dup['exons'][paralog]}")
    ic = dup.get("intron_check") or {}
    jx = ic.get("junctions")
    if ic.get("single_exon"):
        if jx is None:
            tr.obs("phylo", "стыки экзонов: не проверены (нет CDS-структуры или белка)")
        else:
            tr.obs("phylo", f"стыки экзонов: безынтронная {names[ic['single_exon']]} выравнивается через "
                            f"{jx['spanned']} из {jx['junctions']} стыков экзонов {names[ic['multi_exon']]} без разрыва "
                            f"(покрыто экзонов: {jx['covered_exons']})")
        oi = ic.get("ortholog_introns")
        tr.obs("phylo", "интроны у ортологов многоэкзонной копии: " +
               ("не проверены (ортологи с разметкой не найдены)" if oi is None else
                ("есть у всех " + str(len(ic.get('ortholog_exon_counts') or [])) if oi else "есть не у всех")))
    elif ic.get("status") == "introns_shared" and jx:
        tr.obs("phylo", f"места интронов совпадают у обеих копий: {jx['shared']} из {jx['introns_a']}")
    fl = dup["farthest_lineage"]
    tr.obs("phylo", f"самая дальняя линия с копией: {names[gene_id]} — {LINEAGES[fl[gene_id]][0] if fl[gene_id] >= 0 else 'только dmel'}, "
                    f"{names[paralog]} — {LINEAGES[fl[paralog]][0] if fl[paralog] >= 0 else 'только dmel'}")
    if dup.get("tree_signal"):
        tr.obs("phylo", "дерево генов: " + dup["tree_signal"]["note"])
    if dup["parent"] is None:
        tr.step("Д", "Кто из двух копий родитель?", "признаки не сходятся: направление не определено")
        return _finish(res, tr, "duplication", "direction_unresolved", None, "low")
    if dup["parent"] == gene_id:
        tr.step("Д", "Кто из двух копий родитель?", f"родитель — сам ген {names[gene_id]}, копия — {names[paralog]}")
        tr.interp("decide", "ген — родитель: от него произошла копия (возраст самого гена решают следующие шаги)")
        return _finish(res, tr, "ancient", "parent_of_duplicate", None, "high")
    sub, mech = copy_mechanism(dup, gene_id)
    birth = fl[gene_id] + 1
    res["origin_branch"] = branch_label(birth)
    tr.step("Д", "Кто из двух копий родитель?",
            f"родитель — {names[paralog]}; {names[gene_id]} — копия; механизм: {mech}")
    tr.interp("decide", f"копия появилась на ветви {branch_label(birth)}")
    n_sig = sum(1 for v in s.values() if v)
    return _finish(res, tr, "duplication", sub, res["origin_branch"], "high" if n_sig == 3 else "medium")


MECHANISM_RU = {"retrocopy": "ретрокопия (несёт соединённые экзоны родителя)",
                "putative_retrocopy": "предполагаемая ретрокопия (стыки экзонов или интроны ортологов не проверены)",
                "dna_duplication": "дупликация через ДНК (интроны на тех же местах)",
                "mechanism_unresolved": "механизм дупликации не уточнён"}


def copy_mechanism(dup, copy_gene):
    """Подтип для гена-копии по проверке интронов. Без положительной улики — «не уточнён»."""
    ic = dup.get("intron_check") or {}
    st = ic.get("status")
    if ic.get("single_exon") == copy_gene:
        sub = {"confirmed": "retrocopy", "putative": "putative_retrocopy"}.get(st, "mechanism_unresolved")
    elif st == "introns_shared":
        sub = "dna_duplication"
    else:
        sub = "mechanism_unresolved"
    return sub, MECHANISM_RU[sub]


def _strip_dup(dup):
    if not dup:
        return None
    keep = {k: v for k, v in dup.items() if k not in ("per_species",)}
    keep["per_species"] = {sp: {"present": v["present"],
                                "copies": {g: {kk: c.get(kk) for kk in ("protein", "rbh", "present_by", "locus")}
                                           for g, c in v["copies"].items()},
                                "synteny_neighbors": v["synteny_neighbors"]}
                           for sp, v in dup["per_species"].items()}
    return keep


def _finish(res, tr, verdict, subtype, origin, confidence):
    res.update(verdict=verdict, subtype=subtype, confidence=confidence)
    if origin:
        res["origin_branch"] = origin
    res["path"] = tr.steps
    res["evidence"] = tr.evidence
    return res
