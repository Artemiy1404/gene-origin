#!/usr/bin/env bash
# get_data.sh — скачать все входные данные GeneOrigin v2 (≈ 1,2 ГБ в распакованном виде).
# Запуск: bash get_data.sh            (из папки geneorigin_v2)
set -euo pipefail
mkdir -p data/flybase data/proteomes data/ncbi data/paper
cd data

# 1. Файл выравниваний и список сборок статьи (figshare 19989395)
[ -s supplementary_file_unannotated_alignments.txt ] || \
  curl -sSL -o supplementary_file_unannotated_alignments.txt https://ndownloader.figshare.com/files/35585777
[ -s supplementary_file_genome_assembly.csv ] || \
  curl -sSL -o supplementary_file_genome_assembly.csv https://ndownloader.figshare.com/files/43897596

# 2. FlyBase r6.36 (та же версия, что в статье)
for k in translation CDS transcript gene; do
  f=dmel-all-$k-r6.36.fasta.gz
  [ -s flybase/$f ] || curl -sSL -o flybase/$f https://s3ftp.flybase.org/releases/FB2020_05/dmel_r6.36/fasta/$f
done

# 3. Протеомы 27 видов из статьи (NCBI Datasets); для 5 видов ещё и GFF — нужен для синтении в ветке дупликации
while read sp acc gff; do
  [ -s proteomes/$sp.faa ] && continue
  types="include_annotation_type=PROT_FASTA"
  [ "$gff" = "gff" ] && types="$types&include_annotation_type=GENOME_GFF"
  curl -sSL -o $sp.zip "https://api.ncbi.nlm.nih.gov/datasets/v2/genome/accession/$acc/download?$types"
  if [ "$gff" = "gff" ]; then
    mkdir -p ncbi/$sp && unzip -o -q $sp.zip -d ncbi/$sp
    cp ncbi/$sp/ncbi_dataset/data/*/protein.faa proteomes/$sp.faa
  else
    unzip -o -q -j $sp.zip "*protein.faa" -d tmp_$sp && mv tmp_$sp/protein.faa proteomes/$sp.faa && rm -rf tmp_$sp
  fi
  rm -f $sp.zip
  echo "$sp: $(grep -c '>' proteomes/$sp.faa) белков"
done <<'EOF'
dsim GCF_000754195.2 gff
dyak GCF_000005975.2 gff
dana GCF_003285975.2 gff
dpse GCF_009870125.1 gff
dwil GCF_000005925.1 gff
dsec GCF_004382195.1 -
dere GCF_003286155.1 -
dfic GCF_000220665.1 -
drho GCF_000236305.1 -
dele GCF_000224195.1 -
deug GCF_000236325.1 -
dbia GCF_000233415.1 -
dtak GCF_000224235.1 -
dkik GCF_000224215.1 -
dmir GCF_003369915.1 -
dper GCF_003286085.1 -
sleb GCF_003285725.1 -
bdor GCF_000789215.1 -
blat GCF_001853355.1 -
mdom GCF_000371365.1 -
agam GCF_000005575.2 -
aaeg GCF_002204515.2 -
bmor GCF_000151625.1 -
mpha GCF_013373865.1 -
amel GCF_003254395.2 -
aflo GCF_000184785.3 -
dmag GCF_003990815.1 -
EOF

# 4. Таблицы статьи — ТОЛЬКО для сверки (validate.py); в вердикт не идут
base="https://static-content.springer.com/esm/art%3A10.1038%2Fs41467-024-45028-1/MediaObjects"
for f in 41467_2024_45028_MOESM5_ESM.csv 41467_2024_45028_MOESM7_ESM.txt 41467_2024_45028_MOESM8_ESM.csv; do
  [ -s paper/$f ] || curl -sSL -A "Mozilla/5.0" -o paper/$f "$base/$f"
done
echo "Готово."
