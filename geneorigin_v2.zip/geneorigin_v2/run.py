"""run.py — GeneOrigin v2: последовательное дерево решений на реальных данных.

Примеры:
  python run.py --genes genes.txt                 # список FBgn (по одному в строке)
  python run.py --all-alignments                  # все 780 генов файла выравниваний статьи
  python run.py --genes genes.txt --hits hits.tsv # взять готовый blastp (иначе посчитает сам)
  python run.py --all-alignments --mode standard  # не требовать выравниваемого предкового участка

Выход: results/<FBgn>/evidence.json, results/summary.csv, results/log.txt
"""
import argparse
import csv
import glob
import json
import os
import pickle
import platform
import subprocess
import sys
import time

import yaml

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

from io_utils import read_unannotated_alignments, read_flybase_fasta, read_input_dir  # noqa: E402
from reconstruction import reconstruct, describe as describe_event               # noqa: E402
from gene_structure import FlyBaseIndex                                         # noqa: E402
from regions import classify_species, restatus, is_gene                         # noqa: E402
import homology                                                                 # noqa: E402
from duplication import resolve_parent                                          # noqa: E402
from decision_tree import decide, lineage_table                                 # noqa: E402
from species import DISTANT_ARTHROPODS, LINEAGE_INDEX                           # noqa: E402


def log(msg, fh=None):
    line = time.strftime("%H:%M:%S ") + msg
    print(line, flush=True)
    if fh:
        fh.write(line + "\n")
        fh.flush()


def tool_versions(cfg):
    b = cfg["paths"].get("blast_bin", "")
    out = {"python": platform.python_version()}
    for name, cmd in [("blastp", [os.path.join(b, "blastp"), "-version"]),
                      ("iqtree", [cfg["paths"]["iqtree"], "--version"]),
                      ("aligner", [cfg["paths"]["aligner"], "--version"])]:
        try:
            r = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
            out[name] = (r.stdout or r.stderr).strip().splitlines()[0]
        except Exception as e:                                                  # noqa: BLE001
            out[name] = f"нет ({type(e).__name__})"
    return out


def estimate_loss_rate(all_regions):
    """q = доля видовых линий ВНУТРИ группы с геном (между dmel и самой дальней линией с геном),
    у которых гена на месте нет. Это эмпирическая частота потерь/порчи для этих данных."""
    lost = total = 0
    for reg in all_regions.values():
        lt = lineage_table(reg)
        with_gene = [li for li in lt if lt[li]["has_gene"]]
        if not with_gene:
            continue
        l0 = max(with_gene)
        for li in lt:
            if li < l0:
                total += 1
                lost += 0 if lt[li]["has_gene"] else 1
    return (lost + 1) / (total + 2), lost, total            # сглаживание Лапласа


def load_external(path):
    """TSV: gene<TAB>source<TAB>detail — результаты jackhmmer/tblastn/NCBI web, если команда их сделала."""
    ext = {}
    if path and os.path.exists(path):
        with open(path) as f:
            for line in f:
                if line.startswith("#") or not line.strip():
                    continue
                g, src, *rest = line.rstrip("\n").split("\t")
                ext.setdefault(g, []).append({"source": src, "detail": rest[0] if rest else ""})
    return ext


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--genes")
    ap.add_argument("--all-alignments", action="store_true")
    ap.add_argument("--hits", help="готовый blastp (формат homology.FIELDS); иначе считаем")
    ap.add_argument("--external", help="TSV внешнего поиска гомологов (jackhmmer/tblastn)")
    ap.add_argument("--mode", choices=["strict", "standard"], default="strict",
                    help="strict: предковый участок должен хоть как-то выравниваться")
    ap.add_argument("--out", default="results")
    ap.add_argument("--no-tree", action="store_true", help="не строить дерево генов в ветке дупликации")
    ap.add_argument("--stability", action="store_true", help="проверить устойчивость к порогам")
    ap.add_argument("--input", help="папка с <ген>.fasta: CDS гена + ортологи + участки видов (вместо файла статьи)")
    ap.add_argument("--reconstruct", choices=["auto", "yes", "no"], default="auto",
                    help="реконструкция событий (auto: да, если генов <= 100)")
    ap.add_argument("--report", choices=["auto", "yes", "no"], default="auto",
                    help="HTML-отчёты по генам (auto: да, если генов <= 100)")
    args = ap.parse_args()

    cfg = yaml.safe_load(open(args.config))
    cfg["decide"]["strict_alignable_outgroup"] = args.mode == "strict"
    P = cfg["paths"]
    B = P.get("blast_bin", "")
    os.makedirs(args.out, exist_ok=True)
    fh = open(os.path.join(args.out, "log.txt"), "a")
    log(f"=== GeneOrigin v2, режим {args.mode}, seed {cfg['seed']}", fh)
    log("версии: " + json.dumps(tool_versions(cfg), ensure_ascii=False), fh)
    with open(os.path.join(args.out, "run_params.json"), "w", encoding="utf-8") as pf:
        json.dump({"argv": sys.argv, "args": vars(args), "config": cfg,
                   "started": time.strftime("%Y-%m-%d %H:%M:%S")}, pf, ensure_ascii=False, indent=1, default=str)

    if args.input:
        aln = read_input_dir(args.input)
        log(f"вход из FASTA: {args.input} ({len(aln)} генов); участки оцениваются tblastn вместо Genewise", fh)
    else:
        aln = read_unannotated_alignments(P["alignments"])
    fbd = P["flybase_dir"]
    fb = FlyBaseIndex(*(os.path.join(fbd, f"dmel-all-{k}-r6.36.fasta.gz") for k in ("CDS", "transcript", "gene", "translation")))
    if args.genes:
        genes = [l.split()[0] for l in open(args.genes) if l.strip() and not l.startswith("#")]
    elif args.all_alignments or args.input:
        genes = list(aln)
    else:
        ap.error("укажите --genes, --all-alignments или --input")
    small = len(genes) <= 100
    do_rec = args.reconstruct == "yes" or (args.reconstruct == "auto" and small)
    do_report = args.report == "yes" or (args.report == "auto" and small)
    log(f"генов: {len(genes)}; из них в файле выравниваний: {sum(g in aln for g in genes)}", fh)

    # ---- белок из входа против FlyBase ----
    input_protein, protein_note = {}, {}
    if args.input:
        from Bio.Seq import Seq
        for g in genes:
            if g not in aln:
                continue
            cds = aln[g]["raw"][0]["seq"]
            prot = str(Seq(cds[:len(cds) // 3 * 3]).translate()).rstrip("*")
            input_protein[g] = prot
            fbp = fb.longest_protein(g)
            if fbp and fbp["seq"].rstrip("*") != prot:
                protein_note[g] = ("белок из входного FASTA отличается от белка FlyBase r6.36"
                                   + ("; гомологи взяты из готового файла --hits, посчитанного по белку FlyBase"
                                      if args.hits else "; гомологи искались по белку из входа"))
                log(f"{g}: {protein_note[g]}", fh)
            elif not fbp:
                protein_note[g] = "гена нет в FlyBase r6.36: белок = трансляция CDS из входа; контекст в геноме неизвестен"

    # ---- blastp: паралоги и гомологи ----
    db_dir = os.path.join(args.out, "_blast")
    os.makedirs(db_dir, exist_ok=True)
    dmel_db = os.path.join(db_dir, "dmel")
    tr = read_flybase_fasta(os.path.join(fbd, "dmel-all-translation-r6.36.fasta.gz"))
    if not os.path.exists(dmel_db + ".pin") and not os.path.exists(dmel_db + ".pdb"):
        homology.build_db({}, tr, dmel_db, B)
    if args.hits:
        hits = homology.read_hits(args.hits)
    else:
        prots = {os.path.basename(p)[:-4]: p for p in glob.glob(os.path.join(P["proteomes_dir"], "*.faa"))}
        all_db = os.path.join(db_dir, "all28")
        if not os.path.exists(all_db + ".pin") and not os.path.exists(all_db + ".pdb"):
            homology.build_db(prots, tr, all_db, B)
        q = os.path.join(db_dir, "queries.faa")
        with open(q, "w") as f:
            for g in genes:
                # при входе из FASTA ищем по белку ИЗ ВХОДА (он может отличаться от FlyBase)
                p = input_protein.get(g) or (fb.longest_protein(g) or {}).get("seq", "").rstrip("*")
                if p:
                    f.write(f">{g}\n{p}\n")
        out_tsv = os.path.join(db_dir, "hits.tsv")
        log("blastp по протеомам: " + ", ".join(sorted(prots)), fh)
        homology.run_blastp(q, all_db, out_tsv, cfg["homology"]["outside_evalue"], blast_bin=B)
        hits = homology.read_hits(out_tsv)

    # ---- участки у других видов ----
    # Кэш привязан к СОДЕРЖИМОМУ входа: хэш последовательностей и записей Genewise/Spaln гена + порогов orf.
    # Изменили FASTA или пороги -> хэш другой -> участок пересчитывается.
    cache = os.path.join(args.out, "_regions_input.pkl" if args.input else "_regions.pkl")
    stored = pickle.load(open(cache, "rb")) if os.path.exists(cache) else {}
    stored = {g: v for g, v in stored.items() if isinstance(v, tuple) and len(v) == 2}   # старый формат — заново
    all_regions, todo = {}, []
    for g in genes:
        if g not in aln:
            continue
        h = input_hash(aln[g], cfg)
        if g in stored and stored[g][0] == h:
            all_regions[g] = stored[g][1]
        else:
            todo.append((g, h))
    if todo:
        log(f"участки: пересчёт {len(todo)} генов (новые или изменённые входы)", fh)
    for i, (g, h) in enumerate(todo):
        all_regions[g] = classify_species(aln[g], cfg, B)
        stored[g] = (h, all_regions[g])
        if i % 50 == 0:
            log(f"участки: {i}/{len(todo)}", fh)
            pickle.dump(stored, open(cache, "wb"))
    pickle.dump(stored, open(cache, "wb"))
    for g in all_regions:
        restatus(all_regions[g], cfg)
    if cfg["decide"].get("loss_rate_prior"):
        q = cfg["decide"]["loss_rate_prior"]
        log(f"доля потерь внутри групп q = {q:.4f} (из config.yaml)", fh)
    else:
        q, lost, total = estimate_loss_rate(all_regions)
        log(f"доля потерь внутри групп q = {q:.4f} ({lost}/{total}, по всем генам в кэше)", fh)

    # ---- ветка дупликации (лениво) ----
    species_dirs = {os.path.basename(d): d for d in glob.glob(os.path.join(P["ncbi_dir"], "*")) if os.path.isdir(d)}
    tools = None if args.no_tree else {"aligner": P["aligner"], "iqtree": P["iqtree"]}

    dup_cache_path = os.path.join(args.out, "_dup_cache.pkl")
    dup_cache = pickle.load(open(dup_cache_path, "rb")) if os.path.exists(dup_cache_path) else {}

    from duplication import VERSION as DUP_VERSION
    fb_hash = file_hash(os.path.join(fbd, "dmel-all-CDS-r6.36.fasta.gz"))

    def dup(g, par, cached_only=False):
        key = (g, par, tools is not None, DUP_VERSION, fb_hash,
               json.dumps(cfg.get("duplication", {}), sort_keys=True))
        if key not in dup_cache and cached_only:
            return None
        if key not in dup_cache:
            dup_cache[key] = resolve_parent(g, par, fb, dmel_db, species_dirs, cfg, B, tools,
                                            os.path.join(args.out, g, "dup_tree"))
            pickle.dump(dup_cache, open(dup_cache_path, "wb"))
        return dup_cache[key]

    ext = load_external(args.external)
    rows = []
    for g in genes:
        loc = fb.location(g) or {}
        inp = {"name": loc.get("name", ""), "hits": hits.get(g, []), "regions": all_regions.get(g),
               "context": fb.context(g), "dup": dup, "loss_rate": q,
               "external_homology": ext.get(g), "external_checked": bool(args.external)}
        if args.input and fb.longest_protein(g) is None:
            inp["context"] = {"available": False}
        r = decide(g, inp, cfg)
        if g in protein_note:
            r.setdefault("evidence", []).insert(0, {"kind": "observation", "step": "input", "text": protein_note[g]})
        if all_regions.get(g):
            r["species_status"] = {sp: {"lineage": v["lineage"], "status": v["status"],
                                        "grade": v["best"].get("grade"), "p": v["best"].get("p_coding")}
                                   for sp, v in all_regions[g]["species"].items() if v["lineage"] is not None}
        if do_rec and g in aln and all_regions.get(g):
            attach_reconstruction(r, aln[g], all_regions[g], cfg, os.path.join(args.out, g, "asr"),
                                  None if args.no_tree else P["iqtree"])
        if args.stability:
            r["stability"] = stability(g, inp, cfg, r["verdict"], all_regions.get(g))
        os.makedirs(os.path.join(args.out, g), exist_ok=True)
        with open(os.path.join(args.out, g, "evidence.json"), "w") as f:
            json.dump(r, f, ensure_ascii=False, indent=1, default=str)
        if do_report:
            import report
            with open(os.path.join(args.out, g, "report.html"), "w", encoding="utf-8") as f:
                f.write(report.gene_page(json.loads(json.dumps(r, default=str)), back="../index.html"))
        rows.append({"gene": g, "name": r["name"], "verdict": r["verdict"], "subtype": r["subtype"],
                     "origin_branch": r.get("origin_branch") or "", "confidence": r["confidence"],
                     "outgroup_grade": r.get("outgroup_grade", ""),
                     "log10_LR": (r.get("likelihood") or {}).get("log10_LR_denovo_vs_ancient", ""),
                     "losses": ";".join(x["species"] for x in r.get("losses", [])),
                     "stability": (r.get("stability") or {}).get("fraction", ""),
                     "birth_mutations": ";".join(f"{b['type']}@{b['codon']}{'' if b['polarized'] else '?'}"
                                                 for b in r.get("birth_mutations", [])),
                     "path": " > ".join(f"{s['step']}:{s['answer'][:60]}" for s in r["path"])})
    with open(os.path.join(args.out, "summary.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    if do_report:
        import report
        with open(os.path.join(args.out, "index.html"), "w", encoding="utf-8") as f:
            f.write(report.index_page(rows))
        log(f"отчёты: {os.path.join(args.out, 'index.html')}", fh)
    from collections import Counter
    log("вердикты: " + json.dumps(Counter(r["verdict"] for r in rows), ensure_ascii=False), fh)
    log(f"готово: {os.path.join(args.out, 'summary.csv')}", fh)


def file_hash(path, chunk=1 << 20):
    import hashlib
    h = hashlib.sha1()
    if os.path.exists(path):
        with open(path, "rb") as f:
            for b in iter(lambda: f.read(chunk), b""):
                h.update(b)
    return h.hexdigest()[:16]


def input_hash(gene_rec, cfg):
    """Хэш содержимого входа гена (все записи и их последовательности) + порогов, от которых зависят участки."""
    import hashlib
    payload = json.dumps({"raw": [(r.get("id"), r.get("species"), r.get("annotated"), r.get("seq"))
                                  for r in gene_rec.get("raw", [])],
                          "genewise": gene_rec.get("genewise"), "spaln": gene_rec.get("spaln"),
                          "orf": cfg.get("orf")}, sort_keys=True, default=str)
    return hashlib.sha1(payload.encode()).hexdigest()[:16]


def attach_reconstruction(r, gene_records, regions, cfg, workdir, iqtree):
    """Реконструкция событий: наблюдения по видам + поляризованные события как интерпретации."""
    from decision_tree import lineage_table
    l0 = r.get("l0")
    if l0 is None:
        lt = lineage_table(regions)
        with_gene = [li for li in lt if lt[li]["has_gene"]]
        l0 = max(with_gene) if with_gene else -1
    rec = reconstruct(gene_records, regions, l0, cfg, workdir, iqtree)
    r["reconstruction"] = rec
    ev = r.setdefault("evidence", [])
    from species import SPECIES_NAMES
    for sp, ps in rec["per_species"].items():
        li = LINEAGE_INDEX.get(sp, -1)
        if ps.get("insufficient"):
            ev.append({"kind": "observation", "step": "reconstruction", "species": sp,
                       "text": f"{SPECIES_NAMES.get(sp, sp)}: {ps['insufficient']}"})
        elif li > l0 and ps.get("homologous") and not ps.get("start_triplet"):
            ev.append({"kind": "observation", "step": "reconstruction", "species": sp,
                       "text": f"{SPECIES_NAMES.get(sp, sp)}: позиция старта гена не выровнена — "
                               f"есть ли на этом месте ATG, по выравниванию не определить"})
    for e in rec["events"]:
        if e["role"] in ("birth", "before_birth", "gene_change"):
            kind = "interpretation"
        else:
            kind = "observation"
        ev.append({"kind": kind, "step": "reconstruction", "text": describe_event(e), "role": e["role"],
                   "codon": e["codon"], "branch": e.get("branch")})
    a = rec.get("ancestral") or {}
    for codon, h in (a.get("codons") or {}).items():
        ch = h.get("change_to_gene_state")
        if ch:
            ev.append({"kind": "interpretation", "step": "reconstruction",
                       "text": f"предковая реконструкция (IQ-TREE, {a.get('model')}): кодон {codon} у предка "
                               f"{ch['from']} (вероятность {ch['prob_from']:.2f}), стал {ch['to']} на ветви {ch['branch']}"})
    births = [e for e in rec["events"] if e["role"] == "birth"]
    r["birth_mutations"] = [{"codon": e["codon"], "type": e["type"], "branch": e["branch"],
                             "polarized": e["polarized"], "carriers": e["carriers"]} for e in births]


def stability(g, inp, cfg, base_verdict, regions):
    """Сдвигаем каждый порог в 10 раз строже и мягче; доля прогонов с тем же вердиктом."""
    import copy
    variants = [("orf", "p_coding", 10), ("orf", "p_coding", 0.1), ("orf", "p_trace", 10), ("orf", "p_trace", 0.1),
                ("homology", "outside_evalue", 10), ("homology", "outside_evalue", 0.1),
                ("homology", "paralog_evalue", 10), ("homology", "paralog_evalue", 0.1)]
    same, changed = 0, []
    for sec, key, k in variants:
        c2 = copy.deepcopy(cfg)
        c2[sec][key] = cfg[sec][key] * k
        i2 = dict(inp)
        # ветку дупликации не пересчитываем (дорого): берём готовый результат для той же пары, если он есть
        i2["dup"] = (lambda a, b, _d=inp.get("dup"): _d(a, b, cached_only=True)) if inp.get("dup") else None
        if regions:
            i2["regions"] = restatus(copy.deepcopy(regions), c2)
        v = decide(g, i2, c2)["verdict"]
        if v == base_verdict or (base_verdict == "duplication" and v == "duplication"):
            same += 1
        else:
            changed.append(f"{key}×{k}: {v}")
    return {"fraction": round(same / len(variants), 2), "changed": changed}


if __name__ == "__main__":
    main()
