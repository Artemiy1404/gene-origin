"""validate.py — проверка GeneOrigin v2 по ответам статьи (Supplementary Data 2 и 5).

python validate.py --summary results/summary.csv --out results/validation

Что считает:
 1. Матрица «наш вердикт × ответ статьи» для 780 генов файла (520 de novo / 260 отсеяны).
 2. Чувствительность, специфичность, точность, каппа Коэна + 95 % ДИ Уилсона.
 3. Ветвь рождения: совпадение Br с lineage_age статьи.
 4. Манн–Уитни: отличаются ли непрерывные оценки системы у de novo и отсеянных генов статьи;
    AUC = U / (n1·n2) с бутстреп-ДИ (1000 повторов, seed 42).
 5. Калибровка: доля подтверждённых статьёй среди наших вызовов по уровням уверенности.
 6. Положительный контроль метода: Манн–Уитни для GC-состава CDS (в статье p = 3e-139).
 7. Вложенные гены: точный тест Фишера (de novo против остальных генов и против отсеянных).
"""
import argparse
import csv
import gzip
import json
import math
import os
import random
import sys

import numpy as np
import pandas as pd
from scipy import stats

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))


def wilson(k, n, z=1.96):
    if n == 0:
        return (float("nan"), float("nan"))
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return (round(c - h, 3), round(c + h, 3))


def mwu(x_pos, x_neg, n_boot=1000, seed=42):
    """AUC = P(score_de_novo > score_rejected). Возвращает U, p (двусторонний), AUC и бутстреп-ДИ."""
    x_pos, x_neg = np.asarray(x_pos, float), np.asarray(x_neg, float)
    x_pos, x_neg = x_pos[~np.isnan(x_pos)], x_neg[~np.isnan(x_neg)]
    if len(x_pos) < 3 or len(x_neg) < 3:
        return None
    u, p = stats.mannwhitneyu(x_pos, x_neg, alternative="two-sided")
    auc = u / (len(x_pos) * len(x_neg))
    rng = np.random.default_rng(seed)
    boots = []
    for _ in range(n_boot):
        a = rng.choice(x_pos, len(x_pos))
        b = rng.choice(x_neg, len(x_neg))
        boots.append(stats.mannwhitneyu(a, b).statistic / (len(a) * len(b)))
    lo, hi = np.percentile(boots, [2.5, 97.5])
    return {"n_pos": len(x_pos), "n_neg": len(x_neg), "U": float(u), "p": float(p), "AUC": round(float(auc), 3),
            "AUC_95CI": [round(float(lo), 3), round(float(hi), 3)],
            "median_pos": float(np.median(x_pos)), "median_neg": float(np.median(x_neg))}


def load_truth(paper_dir):
    d5 = pd.read_csv(os.path.join(paper_dir, "41467_2024_45028_MOESM8_ESM.csv")).set_index("FBID")
    d2 = pd.read_csv(os.path.join(paper_dir, "41467_2024_45028_MOESM5_ESM.csv"), index_col=False).set_index("FBID")
    return d5, d2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--summary", default="results/summary.csv")
    ap.add_argument("--results", default="results")
    ap.add_argument("--paper", default="data/paper")
    ap.add_argument("--flybase", default="data/flybase")
    ap.add_argument("--out", default="results/validation")
    ap.add_argument("--split", action="store_true",
                    help="метрики на двух случайных половинах (seed 42): разброс оценок; это НЕ проверка на отложенной выборке, потому что правила выбирались на всех 780 генах")
    a = ap.parse_args()
    os.makedirs(a.out, exist_ok=True)
    d5, d2 = load_truth(a.paper)
    s = pd.read_csv(a.summary).set_index("gene")
    col = "Is the gene de novo?"
    s["paper"] = [d5.loc[g, col] if g in d5.index else None for g in s.index]
    s = s[s["paper"].notna()].copy()
    s["paper_denovo"] = s["paper"] == "de novo"
    s["paper_reason"] = s["paper"].map(lambda x: "de novo" if x == "de novo" else
                                       ("blastp 28 членистоногих" if "28 Arthropods" in x else
                                        ("UniProt blastp/jackhmmer" if "UniProt" in x else "tblastn NCBI")))
    s["our_denovo"] = s["verdict"] == "de_novo"
    rep = {"n_genes": int(len(s))}

    # ---- 1–2 матрица и метрики ----
    cm = pd.crosstab(s["paper_reason"], s["verdict"])
    cm.to_csv(os.path.join(a.out, "confusion.csv"))
    tp = int((s.our_denovo & s.paper_denovo).sum())
    fp = int((s.our_denovo & ~s.paper_denovo).sum())
    fn = int((~s.our_denovo & s.paper_denovo).sum())
    tn = int((~s.our_denovo & ~s.paper_denovo).sum())
    decided = s[s.verdict != "insufficient_data"]
    po = (tp + tn) / len(s)
    pe = ((tp + fp) * (tp + fn) + (fn + tn) * (fp + tn)) / len(s) ** 2
    rep["binary_de_novo"] = {
        "TP": tp, "FP": fp, "FN": fn, "TN": tn,
        "sensitivity": round(tp / (tp + fn), 3), "sensitivity_95CI": wilson(tp, tp + fn),
        "specificity": round(tn / (tn + fp), 3), "specificity_95CI": wilson(tn, tn + fp),
        "precision": round(tp / (tp + fp), 3) if tp + fp else None, "precision_95CI": wilson(tp, tp + fp),
        "accuracy": round(po, 3), "cohen_kappa": round((po - pe) / (1 - pe), 3),
        "insufficient_data": int((s.verdict == "insufficient_data").sum()),
        "accuracy_on_decided": round(float((decided.our_denovo == decided.paper_denovo).mean()), 3),
    }
    # биномиальный тест: лучше ли «угадывания по доле» (precision против базовой доли de novo)
    base = s.paper_denovo.mean()
    if tp + fp:
        rep["binary_de_novo"]["precision_vs_base_rate_p"] = float(stats.binomtest(tp, tp + fp, base, alternative="greater").pvalue)
        rep["binary_de_novo"]["base_rate"] = round(float(base), 3)
    rep["by_paper_reason"] = {r: {k: int(v) for k, v in grp.verdict.value_counts().items()}
                              for r, grp in s.groupby("paper_reason")}

    # ---- 3 ветвь рождения ----
    both = s[s.our_denovo & s.paper_denovo]
    ok = [str(both.loc[g, "origin_branch"]) == d2.loc[g, "lineage_age"] for g in both.index if g in d2.index]
    rep["origin_branch_agreement"] = {"k": int(sum(ok)), "n": len(ok), "fraction": round(sum(ok) / max(1, len(ok)), 3),
                                      "95CI": wilson(sum(ok), len(ok))}
    # совпадение ветви по всем 520 (где система её вычислила, независимо от вердикта)
    allb = s[s.paper_denovo & s.origin_branch.notna()]
    ok2 = [str(allb.loc[g, "origin_branch"]) == d2.loc[g, "lineage_age"] for g in allb.index if g in d2.index]
    rep["origin_branch_agreement_all520"] = {"k": int(sum(ok2)), "n": len(ok2), "fraction": round(sum(ok2) / max(1, len(ok2)), 3)}

    # ---- 4 Манн–Уитни по непрерывным оценкам ----
    feats = {}
    for g in s.index:
        ev = json.load(open(os.path.join(a.results, g, "evidence.json")))
        lik = ev.get("likelihood") or {}
        pr = ev.get("outgroup_p_random") or {}
        hits = [h for h in ev.get("evidence", []) if h.get("evalue") is not None and h["step"] == "homology"]
        min_e = min([h["evalue"] for h in hits], default=1.0)
        feats[g] = {"log10_LR": lik.get("log10_LR_denovo_vs_ancient", np.nan),
                    "outgroup_max_p_random": max(pr.values()) if pr else np.nan,
                    "neg_log10_best_homolog_E": -math.log10(max(min_e, 1e-300)),
                    "neg_log10_best_outside_E": -math.log10(max(ev.get("best_outside_E", 1.0), 1e-300)) if "best_outside_E" in ev else np.nan,
                    "protein_len_aa": json.load(open(os.path.join(a.results, g, "evidence.json"))).get("protein_len", np.nan),
                    "n_losses": len(ev.get("losses", [])) if ev.get("losses") is not None else np.nan}
    F = pd.DataFrame(feats).T
    s = s.drop(columns=[c for c in F.columns if c in s.columns]).join(F)
    rep["mann_whitney"] = {}
    for f in F.columns:
        r = mwu(s.loc[s.paper_denovo, f].astype(float), s.loc[~s.paper_denovo, f].astype(float))
        if r:
            rep["mann_whitney"][f] = r

    # ---- 5 калибровка уверенности ----
    cal = {}
    for c, grp in s[s.our_denovo].groupby("confidence"):
        k = int(grp.paper_denovo.sum())
        cal[c] = {"n": len(grp), "confirmed": k, "fraction": round(k / len(grp), 3), "95CI": wilson(k, len(grp))}
    rep["calibration_de_novo_calls"] = cal

    # ---- 6–7 контроли: GC и вложенность ----
    try:
        from io_utils import read_flybase_fasta
        from gene_structure import FlyBaseIndex
        cds = {}
        for c in read_flybase_fasta(os.path.join(a.flybase, "dmel-all-CDS-r6.36.fasta.gz")):
            for p in c["parent"]:
                if p not in cds or len(c["seq"]) > len(cds[p]):
                    cds[p] = c["seq"]
        gc = {g: (v.count("G") + v.count("C")) / len(v) for g, v in cds.items() if v}
        dn_all = set(d2.index)
        rest = [gc[g] for g in d5.index if g in gc and g not in dn_all]
        rep["control_gc_paper_de_novo_vs_other"] = mwu([gc[g] for g in dn_all if g in gc], rest)
        rep["control_gc_paper_de_novo_vs_other"]["comment"] = "в статье (рис. 2a) p = 3e-139"
    except Exception as e:                                                       # noqa: BLE001
        rep["control_gc_error"] = str(e)

    # ---- 8 реконструкция событий: явная поломка рамки у выровненного внешнего вида ----
    brk = {}
    for g in s.index:
        ev = json.load(open(os.path.join(a.results, g, "evidence.json")))
        rec = ev.get("reconstruction")
        if rec is None:
            continue
        evs = rec.get("events", [])
        brk[g] = (any(e["role"] in ("birth", "before_birth", "outgroup_lineage") and
                      e["type"] in ("start", "stop", "stop_lost", "frameshift") for e in evs),
                  any(e["role"] == "birth" and e.get("polarized") for e in evs))
    if brk:
        sub = s.loc[list(brk)]
        has = pd.Series({g: v[0] for g, v in brk.items()})
        pol = pd.Series({g: v[1] for g, v in brk.items()})
        k1, n1 = int(has[sub.paper_denovo].sum()), int(sub.paper_denovo.sum())
        k2, n2 = int(has[~sub.paper_denovo].sum()), int((~sub.paper_denovo).sum())
        orr, p = stats.fisher_exact([[k1, n1 - k1], [k2, n2 - k2]])
        rep["reconstruction_outgroup_break"] = {"de_novo": [k1, n1], "rejected": [k2, n2], "odds_ratio": float(orr),
                                                "fisher_p": float(p), "polarized_birth_genes": int(pol.sum())}
    # ---- ген-копия, чьё семейство предположительно de novo (Д5: два отдельных ответа) ----
    fam = {}
    for g in s.index:
        fp = os.path.join(a.results, g, "evidence.json")
        if os.path.exists(fp):
            ev = json.load(open(fp))
            fam[g] = bool(ev.get("family_origin")) and ev.get("verdict") == "duplication"
    if fam:
        s["copy_of_de_novo_family"] = pd.Series(fam).reindex(s.index).fillna(False).astype(bool)
        k = int((s.copy_of_de_novo_family & s.paper_denovo).sum())
        tp_f = int(((s.our_denovo | s.copy_of_de_novo_family) & s.paper_denovo).sum())
        rep["copy_of_de_novo_family"] = {
            "paper_de_novo_called_duplication_of_de_novo_family": k,
            "all_such_genes": int(s.copy_of_de_novo_family.sum()),
            "sensitivity_gene_or_family": round(tp_f / max(1, int(s.paper_denovo.sum())), 3),
            "note": "ген возник дупликацией, а его семейство — предположительно de novo; в основной матрице это не de novo"}
    s.to_csv(os.path.join(a.out, "per_gene.csv"))
    if a.split:
        rng = random.Random(42)
        idx = list(s.index)
        rng.shuffle(idx)
        half = len(idx) // 2
        for name, part in (("train", idx[:half]), ("test", idx[half:])):
            t = s.loc[part]
            tp_ = int((t.our_denovo & t.paper_denovo).sum()); fp_ = int((t.our_denovo & ~t.paper_denovo).sum())
            fn_ = int((~t.our_denovo & t.paper_denovo).sum()); tn_ = int((~t.our_denovo & ~t.paper_denovo).sum())
            rep[f"split_{name}"] = {"note": "случайная половина готовых результатов; не отложенная выборка", "n": len(t), "sensitivity": round(tp_ / max(1, tp_ + fn_), 3),
                                    "specificity": round(tn_ / max(1, tn_ + fp_), 3),
                                    "precision": round(tp_ / max(1, tp_ + fp_), 3)}
    with open(os.path.join(a.out, "validation.json"), "w") as f:
        json.dump(rep, f, ensure_ascii=False, indent=1, default=float)
    print(cm.to_string())
    print(json.dumps(rep, ensure_ascii=False, indent=1, default=float))


if __name__ == "__main__":
    main()
